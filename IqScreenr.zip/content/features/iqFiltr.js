/**
 * IqFiltr Module
 * Removes tweets/replies/quoted posts based on IQ score thresholds
 * Elements are removed immediately after IQ calculation, before any animations
 */

(function() {
  'use strict';

  /**
   * Get settings helper
   */
  function getSettings() {
    return window.Settings || {};
  }

  /**
   * Get current user's handle
   * @returns {Promise<string|null>} Current user's handle or null
   */
  async function getCurrentUserHandle() {
    const getUserAverageIQ = () => window.UserAverageIQ || {};
    const { getUserHandle } = getUserAverageIQ();

    // Try UserAverageIQ first
    if (getUserHandle) {
      const handle = await getUserHandle();
      if (handle) {
        return handle;
      }
    }

    // Fallback 1: Try storage directly
    const storedHandle = await new Promise((resolve) => {
      chrome.storage.sync.get(['twitterHandle', 'userHandle', 'handle'], (result) => {
        const handle = result.twitterHandle || result.userHandle || result.handle;
        resolve(handle ? handle.toLowerCase().trim().replace(/^@/, '') : null);
      });
    });

    if (storedHandle) {
      return storedHandle;
    }

    // Fallback 2: Check URL if on own profile or own tweet page
    const pathname = window.location.pathname;
    const urlMatch = pathname.match(/^\/([a-zA-Z0-9_]+)/);
    if (urlMatch) {
      const urlHandle = urlMatch[1].toLowerCase();

      // Check if Edit Profile button exists (indicates own profile)
      const editProfileButton = document.querySelector('a[data-testid="editProfileButton"]');
      if (editProfileButton) {
        return urlHandle;
      }
    }

    return null;
  }

  /**
   * Get tweet handle from element
   * @param {HTMLElement} tweetElement - The tweet element
   * @returns {string|null} The tweet handle or null
   */
  function getTweetHandle(tweetElement) {
    if (!tweetElement) {
      return null;
    }

    // First try to get from data attribute (set during processing)
    const handle = tweetElement.getAttribute('data-handle');
    if (handle) {
      return handle.toLowerCase().trim().replace(/^@/, '');
    }

    // Fallback: try to extract from element
    const getTextExtraction = () => window.TextExtraction || {};
    const { extractTweetHandle } = getTextExtraction();
    if (extractTweetHandle) {
      const extractedHandle = extractTweetHandle(tweetElement);
      if (extractedHandle) {
        return extractedHandle.toLowerCase().trim().replace(/^@/, '');
      }
    }

    return null;
  }

  /**
   * Check if an element is a reply
   * @param {HTMLElement} tweetElement - The tweet element to check
   * @returns {boolean} True if the element is a reply
   */
  function isReply(tweetElement) {
    if (!tweetElement) return false;

    // Check for reply indicators
    const hasReplyIndicator = tweetElement.querySelector('[aria-label*="Replying to"]') ||
                              tweetElement.querySelector('[data-testid*="reply"]') ||
                              tweetElement.closest('[data-testid="tweet"]')?.previousElementSibling;

    // Check if it's in a thread (has previous sibling tweet)
    const isInThread = tweetElement.previousElementSibling &&
                      (tweetElement.previousElementSibling.querySelector('[data-testid="tweet"]') ||
                       tweetElement.previousElementSibling.querySelector('article[role="article"]'));

    return !!(hasReplyIndicator || isInThread);
  }

  /**
   * Check if an element is a quoted tweet/post (a tweet that quotes another tweet)
   * @param {HTMLElement} tweetElement - The tweet element to check
   * @returns {boolean} True if the element is a quoted post
   */
  function isQuotedPost(tweetElement) {
    if (!tweetElement) return false;

    // A quote tweet is a tweet that contains a quoted tweet container
    // Check for quoted tweet containers within this tweet
    const quotedSelectors = [
      '[data-testid="quotedTweet"]',
      '[data-testid="quoteTweet"]'
    ];

    for (const selector of quotedSelectors) {
      try {
        const quotedContainer = tweetElement.querySelector(selector);
        if (quotedContainer) {
          // This tweet contains a quoted tweet, so it's a quote tweet
          return true;
        }
      } catch (e) {
        // Ignore selector errors
      }
    }

    // Also check if this element itself is marked as a quote tweet
    // (sometimes the main tweet element has this attribute)
    if (tweetElement.getAttribute('data-testid') === 'quotedTweet' ||
        tweetElement.getAttribute('data-testid') === 'quoteTweet') {
      return true;
    }

    return false;
  }

  /**
   * Check if an element is a regular tweet (not a reply or quoted post)
   * @param {HTMLElement} tweetElement - The tweet element to check
   * @returns {boolean} True if the element is a regular tweet
   */
  function isRegularTweet(tweetElement) {
    if (!tweetElement) return false;
    return !isReply(tweetElement) && !isQuotedPost(tweetElement);
  }

  /**
   * Check if a tweet should be filtered based on settings
   * @param {HTMLElement} tweetElement - The tweet element
   * @param {number} iq - The IQ score
   * @param {number|null} confidence - The confidence percentage (0-100)
   * @returns {Promise<boolean>} True if the tweet should be removed
   */
  async function shouldFilterTweet(tweetElement, iq, confidence) {
    const settings = getSettings();

    // Check if filtering is enabled
    if (!settings.enableIqFiltr) {
      return false;
    }

    // Don't filter tweets that were manually revealed by the user
    // Check both the tweet element and its parent (for nested structures)
    if (tweetElement.hasAttribute('data-iq-manually-revealed') ||
        (tweetElement.parentElement && tweetElement.parentElement.hasAttribute('data-iq-manually-revealed'))) {
      return false;
    }

    // Check if this is the current user's post
    const tweetHandle = getTweetHandle(tweetElement);
    let isUserPost = false;
    if (tweetHandle) {
      const normalizedTweetHandle = tweetHandle.toLowerCase().trim().replace(/^@/, '');

      // Try multiple methods to get user handle
      let currentUserHandle = await getCurrentUserHandle();

      // Fallback: If on a tweet page and URL handle matches tweet handle, it's likely our tweet
      if (!currentUserHandle) {
        const pathname = window.location.pathname;
        const urlMatch = pathname.match(/^\/([a-zA-Z0-9_]+)\/status\//);
        if (urlMatch) {
          const urlHandle = urlMatch[1].toLowerCase();
          if (urlHandle === normalizedTweetHandle) {
            // URL handle matches tweet handle - this is likely our own tweet
            currentUserHandle = urlHandle;
          }
        }
      }

      const normalizedUserHandle = currentUserHandle ? currentUserHandle.toLowerCase().trim().replace(/^@/, '') : null;

      if (normalizedUserHandle && normalizedTweetHandle === normalizedUserHandle) {
        isUserPost = true;
        // If filtering user's posts is disabled, don't filter
        if (settings.filterUserPosts !== true) {
          return false; // Don't filter current user's content
        }
      }
    }

    // Check if tweet is invalid (IQ X) - has data-iq-invalid attribute or iq is null/undefined
    const isInvalid = tweetElement.hasAttribute('data-iq-invalid') ||
                      iq === null ||
                      iq === undefined ||
                      (tweetElement.querySelector && tweetElement.querySelector('.iq-badge-invalid'));

    // Check if filtering invalid tweets is enabled
    const filterInvalid = settings.filterInvalidTweets === true;

    // If filtering invalid tweets is enabled and this tweet is invalid, filter it
    if (filterInvalid && isInvalid) {
      return true;
    }

    // If tweet is invalid but we're not filtering invalid tweets, don't filter based on IQ/confidence
    if (isInvalid) {
      return false;
    }

    // Check which filters are enabled
    const useIQ = settings.useIQInFilter !== false; // Default to true
    const useConfidence = settings.useConfidenceInFilter === true;

    // If no filters are enabled, don't filter
    if (!useIQ && !useConfidence && !filterInvalid) {
      return false;
    }

    let matchesIQThreshold = false;
    let matchesConfidenceThreshold = false;

    // Check IQ threshold if enabled
    if (useIQ) {
      const threshold = settings.filterIQThreshold || 100;
      const direction = settings.filterDirection || 'below';

      if (direction === 'below') {
        matchesIQThreshold = iq < threshold;
      } else {
        matchesIQThreshold = iq > threshold;
      }
    }

    // Check confidence threshold if enabled
    if (useConfidence && confidence !== null && confidence !== undefined) {
      const confidenceThreshold = Number(settings.filterConfidenceThreshold) || 0;
      const confidenceDirection = settings.filterConfidenceDirection || 'below';
      const confidenceValue = Number(confidence);

      // Ensure confidence is a valid number
      if (!isNaN(confidenceValue)) {
        if (confidenceDirection === 'below') {
          matchesConfidenceThreshold = confidenceValue < confidenceThreshold;
        } else {
          // 'above' direction: filter if confidence is greater than threshold
          matchesConfidenceThreshold = confidenceValue > confidenceThreshold;
        }

      }
    }

    // Filter if at least one enabled filter matches (OR logic)
    // If both are enabled, filter if IQ matches OR confidence matches
    // If only one is enabled, filter if that one matches
    let shouldFilter = false;
    if (useIQ && useConfidence) {
      // Both enabled: filter if IQ matches OR confidence matches
      shouldFilter = matchesIQThreshold || matchesConfidenceThreshold;
    } else if (useIQ) {
      // Only IQ enabled: filter if IQ matches
      shouldFilter = matchesIQThreshold;
    } else if (useConfidence) {
      // Only confidence enabled: filter if confidence matches
      shouldFilter = matchesConfidenceThreshold;
    }


    // Filter all post types (tweets, replies, quoted posts) - no type restriction
    return shouldFilter;
  }

  // Track removed and muted tweet IDs to prevent them from reappearing when scrolling
  const removedTweetIds = new Set();
  const mutedTweetIds = new Set();

  // Dedicated MutationObserver to intercept tweets BEFORE they can be processed
  // This runs independently and catches tweets as soon as they're added to DOM
  let filterObserver = null;

  // Batch removal queue to prevent scroll jumping
  let removalQueue = [];
  let removalScheduled = false;
  let lastRemovalTime = 0;
  const REMOVAL_BATCH_DELAY = 50; // Small delay between batches to prevent infinite scroll loops

  /**
   * Get tweet ID from element
   * @param {HTMLElement} tweetElement - The tweet element
   * @returns {string|null} The tweet ID or null
   */
  function getTweetIdFromElement(tweetElement) {
    if (!tweetElement) {
      return null;
    }

    // First try to get from data attribute (set during processing)
    let tweetId = tweetElement.getAttribute('data-tweet-id');
    if (tweetId) {
      return tweetId;
    }

    // Fallback: try to extract from element
    const getTextExtraction = () => window.TextExtraction || {};
    const { extractTweetId } = getTextExtraction();
    if (extractTweetId) {
      const extractedId = extractTweetId(tweetElement);
      if (extractedId) {
        // Store it for future reference
        tweetElement.setAttribute('data-tweet-id', extractedId);
        return extractedId;
      }
    }

    return null;
  }

  /**
   * Remove a tweet element completely from the DOM
   * This removes ALL elements (the entire tweet container)
   * Uses batching to preserve scroll position and prevent infinite scroll loops
   * @param {HTMLElement} tweetElement - The tweet element to remove
   */
  function removeTweetElement(tweetElement) {
    if (!tweetElement || !tweetElement.parentElement) {
      return;
    }

    // Extract and track tweet ID before removal
    const tweetId = getTweetIdFromElement(tweetElement);
    if (tweetId) {
      removedTweetIds.add(tweetId);
      // Remove from muted set if it was muted
      mutedTweetIds.delete(tweetId);
    }

    // Find the outermost container - usually an article or div with role="article"
    // We want to remove the entire tweet, not just parts of it
    let containerToRemove = tweetElement;

    // Try to find the outermost article or tweet container
    let current = tweetElement;
    while (current && current !== document.body) {
      const tagName = current.tagName;
      const role = current.getAttribute('role');
      const testId = current.getAttribute('data-testid');

      // Check if this is a tweet container
      if (tagName === 'ARTICLE' || role === 'article' || testId === 'tweet') {
        containerToRemove = current;
        // Continue up to find the outermost container
        const parent = current.parentElement;
        if (parent && (parent.tagName === 'ARTICLE' || parent.getAttribute('role') === 'article')) {
          current = parent;
          continue;
        }
        break;
      }

      // Also check for common Twitter/X wrapper divs
      if (tagName === 'DIV' && current.classList.contains('css-')) {
        // Check if parent is also a div (likely a wrapper)
        const parent = current.parentElement;
        if (parent && parent.tagName === 'DIV') {
          current = parent;
          continue;
        }
      }

      current = current.parentElement;
    }

    // Add to removal queue instead of removing immediately
    if (containerToRemove && containerToRemove.parentElement) {
      removalQueue.push(containerToRemove);
      scheduleBatchRemoval();
    }
  }

  /**
   * Schedule batch removal of queued elements
   * This preserves scroll position and prevents infinite scroll loops
   */
  function scheduleBatchRemoval() {
    if (removalScheduled || removalQueue.length === 0) {
      return;
    }

    removalScheduled = true;

    // Add a small delay to batch multiple removals together and prevent rapid scroll changes
    const now = Date.now();
    const timeSinceLastRemoval = now - lastRemovalTime;
    const delay = timeSinceLastRemoval < REMOVAL_BATCH_DELAY ? REMOVAL_BATCH_DELAY - timeSinceLastRemoval : 0;

    setTimeout(() => {
      // Use requestAnimationFrame to batch removals and preserve scroll position
      requestAnimationFrame(() => {
      if (removalQueue.length === 0) {
        removalScheduled = false;
        return;
      }

      // Save current scroll position and find a scroll anchor
      const scrollTop = window.scrollY || window.pageYOffset || document.documentElement.scrollTop;
      const scrollHeight = document.documentElement.scrollHeight;
      const viewportHeight = window.innerHeight;

      // Find a visible tweet element that won't be removed to use as scroll anchor
      // This helps maintain scroll position when removing filtered tweets
      let scrollAnchor = null;
      let anchorOffset = 0;

      // Look for a visible tweet that's not in the removal queue
      const allTweets = document.querySelectorAll('article[data-testid="tweet"], article[role="article"]');
      const removalSet = new Set(removalQueue);

      for (let i = 0; i < allTweets.length; i++) {
        const tweet = allTweets[i];
        if (!removalSet.has(tweet) && tweet.parentElement) {
          const rect = tweet.getBoundingClientRect();
          const elementTop = scrollTop + rect.top;
          const elementBottom = elementTop + rect.height;

          // Check if element is visible in viewport
          if (elementTop < scrollTop + viewportHeight && elementBottom > scrollTop) {
            scrollAnchor = tweet;
            anchorOffset = rect.top;
            break;
          }
        }
      }

      // If no anchor found, use the first non-removed tweet
      if (!scrollAnchor && allTweets.length > 0) {
        for (let i = 0; i < allTweets.length; i++) {
          const tweet = allTweets[i];
          if (!removalSet.has(tweet) && tweet.parentElement) {
            scrollAnchor = tweet;
            const rect = tweet.getBoundingClientRect();
            anchorOffset = rect.top;
            break;
          }
        }
      }

      // Remove all queued elements
      const elementsToRemove = [...removalQueue];
      removalQueue = [];

      elementsToRemove.forEach(element => {
        if (element && element.parentElement) {
          element.remove();
        }
      });

      // Restore scroll position after removals
      // Use requestAnimationFrame to ensure DOM has updated
      requestAnimationFrame(() => {
        const newScrollHeight = document.documentElement.scrollHeight;
        const heightDiff = scrollHeight - newScrollHeight;

        // Calculate new scroll position
        let newScrollTop = scrollTop;

        // If we have a scroll anchor, use it to maintain position
        if (scrollAnchor && scrollAnchor.parentElement) {
          const newRect = scrollAnchor.getBoundingClientRect();
          const newAnchorTop = window.scrollY + newRect.top;
          // Calculate how much the anchor moved
          const anchorMovement = newRect.top - anchorOffset;
          // Adjust scroll to compensate
          newScrollTop = scrollTop - anchorMovement;
        } else {
          // Fallback: if we removed content, try to maintain relative position
          if (heightDiff > 0 && scrollTop > 0) {
            // Don't adjust too aggressively - only if significant content was removed
            // This prevents triggering infinite scroll
            if (heightDiff > viewportHeight * 0.5) {
              newScrollTop = Math.max(0, scrollTop - Math.min(heightDiff * 0.3, scrollTop * 0.2));
            }
          }
        }

        // Ensure scroll position is valid
        newScrollTop = Math.max(0, Math.min(newScrollTop, newScrollHeight - viewportHeight));

        // Restore scroll position
        window.scrollTo({
          top: newScrollTop,
          behavior: 'instant'
        });

        removalScheduled = false;
        lastRemovalTime = Date.now();

        // If there are more items queued, schedule another batch
        if (removalQueue.length > 0) {
          scheduleBatchRemoval();
        }
      });
      });
    }, delay);
  }

  /**
   * Mute a tweet element - hide content and show placeholder matching X's muted post style
   * @param {HTMLElement} tweetElement - The tweet element to mute
   * @param {number|null} iq - Optional IQ score (for generating filter message)
   * @param {string|null} filterDirection - Optional filter direction ('below' or 'above')
   * @param {number|null} filterThreshold - Optional filter threshold
   */
  function muteTweetElement(tweetElement, iq = null, filterDirection = null, filterThreshold = null) {
    if (!tweetElement || !tweetElement.parentElement) {
      return;
    }

    // Extract and track tweet ID
    const tweetId = getTweetIdFromElement(tweetElement);
    if (tweetId) {
      mutedTweetIds.add(tweetId);
      // Remove from removed set if it was removed (shouldn't happen, but safety check)
      removedTweetIds.delete(tweetId);
    }

    // Check if already muted or manually revealed
    if (tweetElement.hasAttribute('data-iq-muted') || tweetElement.hasAttribute('data-iq-manually-revealed')) {
      return;
    }

    // Mark as muted and filtered to prevent any processing
    tweetElement.setAttribute('data-iq-muted', 'true');
    tweetElement.setAttribute('data-iq-filtered', 'true');
    tweetElement.setAttribute('data-iq-processing', 'true'); // Prevent processing

    // Find the main tweet content area
    const tweetContentArea = tweetElement.querySelector('[data-testid="tweet"]') || tweetElement;

    // Find and hide the avatar container
    const avatarContainer = tweetContentArea.querySelector('[data-testid="Tweet-User-Avatar"]');
    let avatarParent = null;
    if (avatarContainer) {
      // Find the parent container that holds the avatar
      // Look for the div with classes like r-18kxxzh that contains the avatar
      avatarParent = avatarContainer.closest('div.r-18kxxzh') ||
                     avatarContainer.closest('div[class*="r-18kxxzh"]') ||
                     avatarContainer.parentElement;

      if (avatarParent) {
        avatarParent.style.setProperty('display', 'none', 'important');
        avatarParent.setAttribute('data-iq-hidden-avatar', 'true');
      }
    }

    // Find the container that holds user info, tweet text, and engagement buttons
    // This is the div that comes after the avatar container
    // Look for the div with class r-1iusvr4 that contains the content (not the placeholder)
    let contentContainer = null;

    // Look for the div that contains User-Name, tweetText, and engagement bar
    const userInfo = tweetContentArea.querySelector('[data-testid="User-Name"]');
    const tweetText = tweetContentArea.querySelector('[data-testid="tweetText"]');
    const engagementBar = tweetContentArea.querySelector('[role="group"]');

    // Strategy: Find the div.r-1iusvr4 that contains the content elements
    // This is the content wrapper that comes after the avatar
    const contentWrappers = tweetContentArea.querySelectorAll('div.r-1iusvr4');
    for (const wrapper of contentWrappers) {
      // Skip if this is our placeholder
      if (wrapper.hasAttribute('data-iq-placeholder')) {
        continue;
      }

      // Check if this wrapper contains the actual content
      const hasUserInfo = userInfo && wrapper.contains(userInfo);
      const hasTweetText = tweetText && wrapper.contains(tweetText);
      const hasEngagement = engagementBar && wrapper.contains(engagementBar);

      // If it has at least user info or tweet text, and it's not the entire tweet
      if ((hasUserInfo || hasTweetText) &&
          wrapper !== tweetContentArea &&
          wrapper !== tweetElement &&
          wrapper.tagName !== 'ARTICLE' &&
          wrapper.getAttribute('data-testid') !== 'tweet') {
        // Prefer wrappers that have all three elements
        if (hasUserInfo && hasTweetText && hasEngagement) {
          contentContainer = wrapper;
          break;
        } else if (!contentContainer) {
          // Use this as fallback if we haven't found a better match
          contentContainer = wrapper;
        }
      }
    }

    // If we still don't have a container, try finding the parent of User-Name
    // but be very careful not to select too high
    if (!contentContainer && userInfo) {
      let current = userInfo.parentElement;
      let depth = 0;
      const maxDepth = 5; // Limit how far up we go

      while (current && current !== tweetContentArea && depth < maxDepth) {
        // Never select article or tweet containers
        if (current.tagName === 'ARTICLE' ||
            current.getAttribute('data-testid') === 'tweet' ||
            current === tweetElement) {
          break;
        }

        // Check if this container has the content elements
        const hasUserInfo = current.contains(userInfo);
        const hasTweetText = !tweetText || current.contains(tweetText);
        const hasEngagement = !engagementBar || current.contains(engagementBar);

        // If it has all elements and is a reasonable size, use it
        if (hasUserInfo && hasTweetText && hasEngagement) {
          // Make sure it's not too large (not the entire tweet structure)
          const children = current.children;
          if (children.length <= 10) { // Reasonable number of direct children
            contentContainer = current;
            break;
          }
        }

        current = current.parentElement;
        depth++;
      }
    }

    // Final safety check: make sure we're not hiding the entire tweet
    if (contentContainer) {
      // If the content container is the tweetContentArea or tweetElement itself, don't use it
      if (contentContainer === tweetContentArea ||
          contentContainer === tweetElement ||
          contentContainer.tagName === 'ARTICLE' ||
          contentContainer.getAttribute('data-testid') === 'tweet') {
        contentContainer = null;
      }
    }

    // Also find and hide tweet text, views/timestamp, and engagement bar separately if they're not in the content container
    const tweetTextContainer = tweetText ? tweetText.closest('div.r-1s2bzr4') || tweetText.parentElement : null;
    const engagementBarContainer = engagementBar ? engagementBar.parentElement : null;

    // Find the views/timestamp container (div.r-12kyg2d that contains timestamp and views)
    const viewsContainer = tweetContentArea.querySelector('div.r-12kyg2d');

    // Store all hidden elements for restoration
    const hiddenElements = [];

    // If we found a content container, hide it and add placeholder
    if (contentContainer && contentContainer.parentElement) {
      // Hide the content container
      contentContainer.style.setProperty('display', 'none', 'important');
      contentContainer.setAttribute('data-iq-hidden-content', 'true');
      hiddenElements.push(contentContainer);
    }

    // Also hide tweet text container if it's not already hidden
    if (tweetTextContainer &&
        !tweetTextContainer.hasAttribute('data-iq-hidden-content') &&
        tweetTextContainer !== contentContainer &&
        tweetTextContainer.parentElement) {
      tweetTextContainer.style.setProperty('display', 'none', 'important');
      tweetTextContainer.setAttribute('data-iq-hidden-content', 'true');
      hiddenElements.push(tweetTextContainer);
    }

    // Also hide engagement bar container if it's not already hidden
    if (engagementBarContainer &&
        !engagementBarContainer.hasAttribute('data-iq-hidden-content') &&
        engagementBarContainer !== contentContainer &&
        engagementBarContainer !== tweetTextContainer &&
        engagementBarContainer.parentElement) {
      engagementBarContainer.style.setProperty('display', 'none', 'important');
      engagementBarContainer.setAttribute('data-iq-hidden-content', 'true');
      hiddenElements.push(engagementBarContainer);
    }

    // Also hide views/timestamp container if it's not already hidden
    if (viewsContainer &&
        !viewsContainer.hasAttribute('data-iq-hidden-content') &&
        viewsContainer !== contentContainer &&
        viewsContainer !== tweetTextContainer &&
        viewsContainer !== engagementBarContainer &&
        viewsContainer.parentElement) {
      viewsContainer.style.setProperty('display', 'none', 'important');
      viewsContainer.setAttribute('data-iq-hidden-content', 'true');
      hiddenElements.push(viewsContainer);
    }

    // Only proceed if we have at least one element to hide
    if (hiddenElements.length === 0) {
      return;
    }

    // Generate filter message based on IQ and filter direction
    let filterMessage = 'This post has been filtered.';
    if (iq !== null && iq !== undefined && filterDirection && filterThreshold !== null && filterThreshold !== undefined) {
      const settings = getSettings();
      const useIQ = settings.useIQInFilter !== false; // Default to true
      
      if (useIQ) {
        if (filterDirection === 'below') {
          filterMessage = `This post has been muted for being too low IQ (< ${filterThreshold} IQ).`;
        } else if (filterDirection === 'above') {
          filterMessage = `This post has been muted for being too high IQ (> ${filterThreshold} IQ).`;
        }
      }
    }

    // Create placeholder matching X's exact styling
    const placeholder = document.createElement('div');
    placeholder.className = 'css-175oi2r r-1iusvr4 r-16y2uox r-1777fci';
    placeholder.setAttribute('data-iq-placeholder', 'true');

    placeholder.innerHTML = `
        <div class="css-175oi2r r-1awozwy r-g2wdr4 r-16cnnyw r-1867qdf r-1phboty r-rs99b7 r-18u37iz r-1wtj0ep r-1mmae3n r-n7gxbd">
          <div class="css-175oi2r r-1adg3ll r-1wbh5a2 r-jusfrs">
            <div dir="auto" class="css-146c3p1 r-bcqeeo r-1ttztb7 r-qvutc0 r-37j5jr r-a023e6 r-rjixqe r-16dba41" style="color: rgb(113, 118, 123);">
              <span dir="ltr" class="css-1jxf684 r-bcqeeo r-1ttztb7 r-qvutc0 r-poiln3 r-1udh08x">
                <span class="css-1jxf684 r-bcqeeo r-1ttztb7 r-qvutc0 r-poiln3">${filterMessage}</span>
              </span>
            </div>
          </div>
          <div class="css-175oi2r r-1kqz2tg">
            <button role="button" class="css-175oi2r r-sdzlij r-1phboty r-rs99b7 r-lrvibr r-faml9v r-2dysd3 r-15ysp7h r-4wgw6l r-3pj75a r-1loqt21 r-o7ynqc r-6416eg r-1ny4l3l iq-filtr-view-button" type="button" style="background-color: rgba(0, 0, 0, 0); border-color: rgba(0, 0, 0, 0);">
              <div dir="ltr" class="css-146c3p1 r-bcqeeo r-qvutc0 r-37j5jr r-q4m81j r-a023e6 r-rjixqe r-b88u0q r-1awozwy r-6koalj r-18u37iz r-16y2uox r-1777fci" style="color: rgb(239, 243, 244);">
                <span class="css-1jxf684 r-dnmrzs r-1udh08x r-1udbk01 r-3s2u2q r-bcqeeo r-1ttztb7 r-qvutc0 r-poiln3 r-1b43r93 r-1cwl3u0">
                  <span class="css-1jxf684 r-bcqeeo r-1ttztb7 r-qvutc0 r-poiln3">View</span>
                </span>
              </div>
            </button>
          </div>
        </div>
      `;

    // Store references to hidden content for restoration
    placeholder._hiddenContent = contentContainer;
    placeholder._hiddenElements = hiddenElements; // Store all hidden elements
    placeholder._hiddenAvatar = avatarParent;

    // Add click handler to reveal
      const viewButton = placeholder.querySelector('.iq-filtr-view-button');
    if (viewButton) {
      // Add hover effects
      viewButton.addEventListener('mouseenter', () => {
        viewButton.style.backgroundColor = 'rgba(239, 243, 244, 0.1)';
      });
      viewButton.addEventListener('mouseleave', () => {
        viewButton.style.backgroundColor = 'rgba(0, 0, 0, 0)';
      });

      viewButton.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        if (!tweetElement.hasAttribute('data-iq-manually-revealed')) {
          revealMutedTweet(tweetElement);
        }
      }, true);

    }

    // Also allow clicking the placeholder itself
    placeholder.addEventListener('click', (e) => {
        if (!e.target.closest('.iq-filtr-view-button') && !tweetElement.hasAttribute('data-iq-manually-revealed')) {
        e.preventDefault();
        e.stopPropagation();
        revealMutedTweet(tweetElement);
      }
    }, true);

    // Insert placeholder - find a good insertion point
    let insertionPoint = null;
    if (contentContainer && contentContainer.parentElement) {
      insertionPoint = contentContainer.parentElement;
      insertionPoint.insertBefore(placeholder, contentContainer.nextSibling);
    } else if (tweetTextContainer && tweetTextContainer.parentElement) {
      insertionPoint = tweetTextContainer.parentElement;
      insertionPoint.insertBefore(placeholder, tweetTextContainer.nextSibling);
    } else if (engagementBarContainer && engagementBarContainer.parentElement) {
      insertionPoint = engagementBarContainer.parentElement;
      insertionPoint.insertBefore(placeholder, engagementBarContainer.nextSibling);
    } else if (tweetContentArea) {
      // Last resort: insert at the end of the tweet content area
      tweetContentArea.appendChild(placeholder);
    }
  }

  /**
   * Reveal a muted tweet
   * @param {HTMLElement} tweetElement - The muted tweet element
   */
  async function revealMutedTweet(tweetElement) {
    if (!tweetElement) {
      return;
    }

    // If already revealed, don't do anything
    if (tweetElement.hasAttribute('data-iq-manually-revealed')) {
      return;
    }

    // If not muted, nothing to reveal
    if (!tweetElement.hasAttribute('data-iq-muted')) {
      return;
    }

    // Remove from muted set if manually revealed
    const tweetId = getTweetIdFromElement(tweetElement);
    if (tweetId) {
      mutedTweetIds.delete(tweetId);
    }

    // Mark as manually revealed - this prevents re-filtering
    tweetElement.setAttribute('data-iq-manually-revealed', 'true');
    tweetElement.removeAttribute('data-iq-muted');

    // Find and remove placeholder
    const placeholder = tweetElement.querySelector('[data-iq-placeholder="true"]');
    if (placeholder) {
      // Restore all hidden elements
      if (placeholder._hiddenElements && Array.isArray(placeholder._hiddenElements)) {
        placeholder._hiddenElements.forEach(element => {
          if (element && element.parentElement) {
            element.style.removeProperty('display');
            element.removeAttribute('data-iq-hidden-content');
          }
        });
      }
      // Also restore the main content container if it exists separately
      if (placeholder._hiddenContent && placeholder._hiddenContent.parentElement) {
        placeholder._hiddenContent.style.removeProperty('display');
        placeholder._hiddenContent.removeAttribute('data-iq-hidden-content');
      }
      // Restore hidden avatar if it exists
      if (placeholder._hiddenAvatar && placeholder._hiddenAvatar.parentElement) {
        placeholder._hiddenAvatar.style.removeProperty('display');
        placeholder._hiddenAvatar.removeAttribute('data-iq-hidden-avatar');
      }
      placeholder.remove();
    }

    // After revealing, check if IQ badge needs to be calculated or restored
    // Find the actual tweet element (handle nested structures)
    const nestedTweet = tweetElement.querySelector('article[data-testid="tweet"]') ||
                        tweetElement.querySelector('article[role="article"]');
    const actualTweetElement = nestedTweet && nestedTweet !== tweetElement ? nestedTweet : tweetElement;

    // Check if IQ result is stored on the element itself (might have been calculated but not cached)
    const iqResultOnElement = actualTweetElement._iqResult || tweetElement._iqResult;

    // Check if badge exists and its state - check ALL badges in both actualTweetElement and tweetElement
    const allBadgesInActual = actualTweetElement.querySelectorAll('.iq-badge');
    const allBadgesInOuter = tweetElement !== actualTweetElement ? tweetElement.querySelectorAll('.iq-badge') : [];
    const allBadges = Array.from(new Set([...allBadgesInActual, ...allBadgesInOuter]));
    
    // Find badges with scores and loading badges
    const badgesWithScore = Array.from(allBadges).filter(b => 
      b.hasAttribute('data-iq-score') || b.hasAttribute('data-iq-guess')
    );
    const loadingBadges = Array.from(allBadges).filter(b => 
      b.hasAttribute('data-iq-loading') || b.classList.contains('iq-badge-loading')
    );
    
    const existingBadge = badgesWithScore.length > 0 ? badgesWithScore[0] : 
                          loadingBadges.length > 0 ? loadingBadges[0] : 
                          allBadges.length > 0 ? allBadges[0] : null;
    
    const hasBadgeWithScore = badgesWithScore.length > 0;
    const isBadgeLoading = loadingBadges.length > 0;
    
    // Remove duplicate loading badges if we have a badge with score
    if (hasBadgeWithScore && loadingBadges.length > 0) {
      loadingBadges.forEach(badge => {
        if (badge.parentElement) {
          badge.remove();
        }
      });
    }

    // If badge already has a score or guess, make sure it's visible
    if (hasBadgeWithScore) {
      // Restore badge visibility if it was hidden
      if (existingBadge) {
        const currentDisplay = existingBadge.style.getPropertyValue('display');
        const computedDisplay = window.getComputedStyle(existingBadge).display;
        const computedHeight = window.getComputedStyle(existingBadge).height;
        const computedMaxHeight = window.getComputedStyle(existingBadge).maxHeight;
        
        // Check if badge is hidden (either inline style, computed style, or height constraints)
        if (currentDisplay === 'none' || computedDisplay === 'none' || computedHeight === '0px' || computedMaxHeight === '0px') {
          // Remove all hiding styles - need to use setProperty with empty string to override !important
          existingBadge.style.setProperty('display', 'inline-flex', 'important');
          existingBadge.style.setProperty('height', '', 'important');
          existingBadge.style.setProperty('max-height', '', 'important');
          existingBadge.style.setProperty('min-height', '', 'important');
          
          // Also restore all badges with scores
          badgesWithScore.forEach(badge => {
            badge.style.setProperty('display', 'inline-flex', 'important');
            badge.style.setProperty('height', '', 'important');
            badge.style.setProperty('max-height', '', 'important');
            badge.style.setProperty('min-height', '', 'important');
          });
        }
      }
      return;
    }

    // If there's no badge at all (tweet was muted before IQ was calculated), trigger processing
    if (!isBadgeLoading && !hasBadgeWithScore && allBadges.length === 0 && tweetId) {
      // Clear any flags that might prevent processing
      actualTweetElement.removeAttribute('data-iq-processing');
      actualTweetElement.removeAttribute('data-iq-processing-start');
      tweetElement.removeAttribute('data-iq-processing');
      tweetElement.removeAttribute('data-iq-processing-start');
      
      // Clear analyzed flag AFTER clearing other flags
      actualTweetElement.removeAttribute('data-iq-analyzed');
      tweetElement.removeAttribute('data-iq-analyzed');
      
      // Check if shouldSkipTweet would prevent processing
      const getIqFiltr = () => window.IqFiltr || {};
      const { shouldSkipTweet: shouldSkipTweetCheck } = getIqFiltr();
      if (shouldSkipTweetCheck) {
        const shouldSkipActual = shouldSkipTweetCheck(actualTweetElement);
        const shouldSkipOuter = tweetElement !== actualTweetElement ? shouldSkipTweetCheck(tweetElement) : false;
        
        if (shouldSkipActual || shouldSkipOuter) {
          // Clear the flags that might cause shouldSkipTweet to return true
          actualTweetElement.removeAttribute('data-iq-filtered');
          actualTweetElement.removeAttribute('data-iq-muted');
          actualTweetElement.removeAttribute('data-iq-removed');
          tweetElement.removeAttribute('data-iq-filtered');
          tweetElement.removeAttribute('data-iq-muted');
          tweetElement.removeAttribute('data-iq-removed');
          
          // Also remove from mutedTweetIds set if it exists there
          if (tweetId && mutedTweetIds && mutedTweetIds.has(tweetId)) {
            mutedTweetIds.delete(tweetId);
          }
        }
      }

      // Ensure manually-revealed flag is set on both elements to prevent re-filtering
      // This must be set BEFORE processTweet so checkAndFilter respects it
      tweetElement.setAttribute('data-iq-manually-revealed', 'true');
      actualTweetElement.setAttribute('data-iq-manually-revealed', 'true');

      // Trigger IQ badge calculation
      const tweetProcessor = window.TweetProcessor;
      if (tweetProcessor && tweetProcessor.processTweet) {
        requestAnimationFrame(() => {
          tweetProcessor.processTweet(tweetElement).then(() => {
            // Ensure manually-revealed flag is still set to prevent re-filtering
            tweetElement.setAttribute('data-iq-manually-revealed', 'true');
            actualTweetElement.setAttribute('data-iq-manually-revealed', 'true');
          }).catch(() => {
            // Silently fail
          });
        });
      }
      return;
    }

    // If badge is loading, check if IQ was already calculated and cached
    if (isBadgeLoading && existingBadge && tweetId) {
      const gameManager = window.GameManager || {};
      
      // Also check if there's a badge with score that we might have missed
      if (badgesWithScore.length > 0) {
        loadingBadges.forEach(badge => {
          if (badge.parentElement) {
            badge.remove();
          }
        });
        // Restore visibility of badges with scores
        badgesWithScore.forEach(badge => {
          badge.style.setProperty('display', 'inline-flex', 'important');
          badge.style.setProperty('height', '', 'important');
          badge.style.setProperty('max-height', '', 'important');
          badge.style.setProperty('min-height', '', 'important');
        });
        return;
      }
      
      // First check if IQ result is on the element itself (calculated but not cached)
      if (iqResultOnElement && iqResultOnElement.iq !== undefined && iqResultOnElement.iq !== null) {
        // Use the IQ result from the element
        const { handleNestedStructure } = window.NestedTweetHandler || {};
        let outerElement = null;
        let hasNestedStructure = false;
        if (handleNestedStructure) {
          const nestedResult = handleNestedStructure(tweetElement);
          outerElement = nestedResult.outerElement;
          hasNestedStructure = nestedResult.hasNestedStructure;
        }

        const isNotificationsPage = window.location.href.includes('/notifications');
        const { extractTweetText } = window.TextExtraction || {};
        const tweetText = extractTweetText ? extractTweetText(actualTweetElement) : null;

        // Convert IQ result format
        const iq = iqResultOnElement.iq;
        const result = iqResultOnElement.result || {};
        const confidence = iqResultOnElement.confidence;

        // Update the loading badge with IQ from element
        const { updateBadgeWithIQ } = window.BadgeUpdate || {};
        if (updateBadgeWithIQ && existingBadge) {
          try {
            await updateBadgeWithIQ(
              existingBadge,
              actualTweetElement,
              outerElement,
              hasNestedStructure,
              isNotificationsPage,
              iq,
              result,
              confidence,
              tweetText,
              tweetId
            );
          } catch (error) {
            // Silently fail
          }
        }
        return;
      }
      
      if (gameManager.getCachedRevealedIQResult) {
        // Check for cached IQ result
        const cachedIQResult = await gameManager.getCachedRevealedIQResult(tweetId);
        
        if (cachedIQResult && cachedIQResult.iq) {
          // IQ was already calculated - update the loading badge with cached result
          const { handleNestedStructure } = window.NestedTweetHandler || {};
          let outerElement = null;
          let hasNestedStructure = false;
          if (handleNestedStructure) {
            const nestedResult = handleNestedStructure(tweetElement);
            outerElement = nestedResult.outerElement;
            hasNestedStructure = nestedResult.hasNestedStructure;
          }

          const isNotificationsPage = window.location.href.includes('/notifications');
          const { extractTweetText } = window.TextExtraction || {};
          const tweetText = extractTweetText ? extractTweetText(actualTweetElement) : null;

          // Convert cached IQ format to expected format
          const cachedIQ = {
            iq_estimate: cachedIQResult.iq,
            confidence: cachedIQResult.confidence,
            ...(cachedIQResult.result || {})
          };

          // Update the loading badge with cached IQ
          const { updateBadgeWithIQ } = window.BadgeUpdate || {};
          if (updateBadgeWithIQ) {
            try {
              await updateBadgeWithIQ(
                existingBadge,
                actualTweetElement,
                outerElement,
                hasNestedStructure,
                isNotificationsPage,
                cachedIQ.iq_estimate,
                cachedIQ,
                cachedIQ.confidence,
                tweetText,
                tweetId
              );
            } catch (error) {
              // Silently fail
            }
          }
          return;
        } else {
          // Double-check if there's a badge with score we might have missed (maybe realtime badge)
          // Search more broadly - check the entire tweetElement tree, not just actualTweetElement
          const allBadgesRecheck = tweetElement.querySelectorAll('.iq-badge');
          const badgesWithScoreRecheck = Array.from(allBadgesRecheck).filter(b => 
            b.hasAttribute('data-iq-score') || b.hasAttribute('data-iq-guess')
          );
          
          if (badgesWithScoreRecheck.length > 0) {
            badgesWithScoreRecheck.forEach(badge => {
              badge.style.setProperty('display', 'inline-flex', 'important');
              badge.style.setProperty('height', '', 'important');
              badge.style.setProperty('max-height', '', 'important');
              badge.style.setProperty('min-height', '', 'important');
            });
            // Remove loading badges
            loadingBadges.forEach(badge => {
              if (badge.parentElement) {
                badge.remove();
              }
            });
            return;
          }
          
          // Also check if there's a badge with score in the parent containers
          // (might be in a different part of the DOM structure)
          let parentElement = tweetElement.parentElement;
          let depth = 0;
          while (parentElement && depth < 3) {
            const parentBadges = parentElement.querySelectorAll('.iq-badge');
            const parentBadgesWithScore = Array.from(parentBadges).filter(b => 
              b.hasAttribute('data-iq-score') || b.hasAttribute('data-iq-guess')
            );
            
            if (parentBadgesWithScore.length > 0) {
              parentBadgesWithScore.forEach(badge => {
                badge.style.setProperty('display', 'inline-flex', 'important');
                badge.style.setProperty('height', '', 'important');
                badge.style.setProperty('max-height', '', 'important');
                badge.style.setProperty('min-height', '', 'important');
              });
              // Remove loading badges
              loadingBadges.forEach(badge => {
                if (badge.parentElement) {
                  badge.remove();
                }
              });
              return;
            }
            parentElement = parentElement.parentElement;
            depth++;
          }
          
          // No cached IQ found - trigger processing to calculate it
          // Clear any flags that might prevent processing
          // IMPORTANT: Clear data-iq-analyzed LAST, after clearing other flags
          // This ensures processTweet doesn't return early
          actualTweetElement.removeAttribute('data-iq-processing');
          actualTweetElement.removeAttribute('data-iq-processing-start');
          tweetElement.removeAttribute('data-iq-processing');
          tweetElement.removeAttribute('data-iq-processing-start');
          
          // Clear analyzed flag AFTER clearing other flags
          actualTweetElement.removeAttribute('data-iq-analyzed');
          tweetElement.removeAttribute('data-iq-analyzed');
          
          // Check if shouldSkipTweet would prevent processing
          const getIqFiltr = () => window.IqFiltr || {};
          const { shouldSkipTweet: shouldSkipTweetCheck } = getIqFiltr();
          if (shouldSkipTweetCheck) {
            const shouldSkipActual = shouldSkipTweetCheck(actualTweetElement);
            const shouldSkipOuter = tweetElement !== actualTweetElement ? shouldSkipTweetCheck(tweetElement) : false;
            
            if (shouldSkipActual || shouldSkipOuter) {
              // Clear the flags that might cause shouldSkipTweet to return true
              actualTweetElement.removeAttribute('data-iq-filtered');
              actualTweetElement.removeAttribute('data-iq-muted');
              actualTweetElement.removeAttribute('data-iq-removed');
              tweetElement.removeAttribute('data-iq-filtered');
              tweetElement.removeAttribute('data-iq-muted');
              tweetElement.removeAttribute('data-iq-removed');
              
              // Also remove from mutedTweetIds set if it exists there
              if (tweetId && mutedTweetIds && mutedTweetIds.has(tweetId)) {
                mutedTweetIds.delete(tweetId);
              }
            }
          }

          // Ensure manually-revealed flag is set on both elements to prevent re-filtering
          // This must be set BEFORE processTweet so checkAndFilter respects it
          tweetElement.setAttribute('data-iq-manually-revealed', 'true');
          actualTweetElement.setAttribute('data-iq-manually-revealed', 'true');

          // Trigger IQ badge calculation
          const tweetProcessor = window.TweetProcessor;
          if (tweetProcessor && tweetProcessor.processTweet) {
            requestAnimationFrame(() => {
              tweetProcessor.processTweet(tweetElement).then(() => {
                // Ensure manually-revealed flag is still set to prevent re-filtering
                tweetElement.setAttribute('data-iq-manually-revealed', 'true');
                actualTweetElement.setAttribute('data-iq-manually-revealed', 'true');
                
                // After processing, check again if a badge with score was created
                // Use a retry mechanism with increasing delays
                let retryCount = 0;
                const maxRetries = 5;
                const checkInterval = 500; // Start with 500ms
                
                const checkForBadgeWithScore = () => {
                  retryCount++;
                  
                  const badgesAfterProcess = tweetElement.querySelectorAll('.iq-badge');
                  
                  // Check if IQ result is on the element
                  const iqResultAfterProcess = actualTweetElement._iqResult || tweetElement._iqResult;
                  
                  const badgesWithScoreAfterProcess = Array.from(badgesAfterProcess).filter(b => 
                    (b.hasAttribute('data-iq-score') || b.hasAttribute('data-iq-guess')) &&
                    (!b.hasAttribute('data-iq-loading') && !b.classList.contains('iq-badge-loading'))
                  );
                  
                  if (badgesWithScoreAfterProcess.length > 0) {
                    // Remove loading badges
                    const loadingBadgesAfterProcess = Array.from(badgesAfterProcess).filter(b => 
                      b.hasAttribute('data-iq-loading') || b.classList.contains('iq-badge-loading')
                    );
                    loadingBadgesAfterProcess.forEach(badge => {
                      if (badge.parentElement) {
                        badge.remove();
                      }
                    });
                  } else if (iqResultAfterProcess && iqResultAfterProcess.iq !== undefined && iqResultAfterProcess.iq !== null) {
                    // IQ was calculated but badge wasn't updated - update it manually
                    const { handleNestedStructure } = window.NestedTweetHandler || {};
                    let outerElement = null;
                    let hasNestedStructure = false;
                    if (handleNestedStructure) {
                      const nestedResult = handleNestedStructure(tweetElement);
                      outerElement = nestedResult.outerElement;
                      hasNestedStructure = nestedResult.hasNestedStructure;
                    }
                    
                    const isNotificationsPage = window.location.href.includes('/notifications');
                    const { extractTweetText } = window.TextExtraction || {};
                    const tweetText = extractTweetText ? extractTweetText(actualTweetElement) : null;
                    
                    const loadingBadgeAfterProcess = Array.from(badgesAfterProcess).find(b => 
                      b.hasAttribute('data-iq-loading') || b.classList.contains('iq-badge-loading')
                    );
                    
                    if (loadingBadgeAfterProcess) {
                      const { updateBadgeWithIQ } = window.BadgeUpdate || {};
                      if (updateBadgeWithIQ) {
                        updateBadgeWithIQ(
                          loadingBadgeAfterProcess,
                          actualTweetElement,
                          outerElement,
                          hasNestedStructure,
                          isNotificationsPage,
                          iqResultAfterProcess.iq,
                          iqResultAfterProcess.result || {},
                          iqResultAfterProcess.confidence,
                          tweetText,
                          tweetId
                        ).catch(() => {
                          // Silently fail
                        });
                      }
                    }
                  } else if (retryCount < maxRetries) {
                    // Retry after delay
                    setTimeout(checkForBadgeWithScore, checkInterval);
                  }
                };
                
                // Start checking after initial delay
                setTimeout(checkForBadgeWithScore, checkInterval);
              }).catch(() => {
                // Silently fail
              });
            });
          }
        }
      } else {
        // Fallback: trigger processing
        actualTweetElement.removeAttribute('data-iq-analyzed');
        actualTweetElement.removeAttribute('data-iq-processing');
        actualTweetElement.removeAttribute('data-iq-processing-start');
        tweetElement.removeAttribute('data-iq-analyzed');
        tweetElement.removeAttribute('data-iq-processing');
        tweetElement.removeAttribute('data-iq-processing-start');

        const tweetProcessor = window.TweetProcessor;
        if (tweetProcessor && tweetProcessor.processTweet) {
          requestAnimationFrame(() => {
            tweetProcessor.processTweet(tweetElement).catch(() => {
              // Silently fail
            });
          });
        }
      }
      return;
    }

    // No badge or badge without score/loading state - trigger IQ calculation
    // Clear any flags that might prevent processing
    actualTweetElement.removeAttribute('data-iq-analyzed');
    actualTweetElement.removeAttribute('data-iq-processing');
    actualTweetElement.removeAttribute('data-iq-processing-start');
    tweetElement.removeAttribute('data-iq-analyzed');
    tweetElement.removeAttribute('data-iq-processing');
    tweetElement.removeAttribute('data-iq-processing-start');

    // Trigger IQ badge calculation
    const tweetProcessor = window.TweetProcessor;
    if (tweetProcessor && tweetProcessor.processTweet) {
      // Use requestAnimationFrame to ensure DOM is updated before processing
      requestAnimationFrame(() => {
        tweetProcessor.processTweet(tweetElement).catch(() => {
          // Silently fail if processing fails
        });
      });
    }
  }

  /**
   * Reveal all muted tweets (used when filter is disabled or mode changes)
   */
  function revealAllMutedTweets() {
    const mutedTweets = document.querySelectorAll('[data-iq-muted="true"]');
    mutedTweets.forEach(tweet => {
      // Remove manually revealed flag when filter is disabled
      tweet.removeAttribute('data-iq-manually-revealed');
      revealMutedTweet(tweet);
    });
    // Clear muted set when filter is disabled
    mutedTweetIds.clear();
    // Also remove data attributes from any remaining elements
    document.querySelectorAll('[data-iq-muted]').forEach(el => {
      el.removeAttribute('data-iq-muted');
      el.removeAttribute('data-iq-filtered');
      el.removeAttribute('data-iq-processing');
    });
  }

  /**
   * Clear all removed tweet IDs (used when filter is disabled)
   */
  function clearRemovedTweetIds() {
    removedTweetIds.clear();
    // Also remove data attributes from any remaining elements
    document.querySelectorAll('[data-iq-removed]').forEach(el => {
      el.removeAttribute('data-iq-removed');
      el.removeAttribute('data-iq-filtered');
      el.removeAttribute('data-iq-processing');
    });
  }

  /**
   * Immediately intercept and filter a tweet if it was previously removed/muted
   * This is called by the MutationObserver as soon as tweets are added to DOM
   * @param {HTMLElement} tweetElement - The tweet element to check
   * @returns {boolean} True if the tweet was intercepted and filtered
   */
  function interceptTweetImmediately(tweetElement) {
    if (!tweetElement) {
      return false;
    }

    // Mark as intercepted to prevent any processing
    tweetElement.setAttribute('data-iq-filtered', 'true');
    tweetElement.setAttribute('data-iq-processing', 'true'); // Prevent processing

    const tweetId = getTweetIdFromElement(tweetElement);
    if (!tweetId) {
      // If we can't get ID yet, try again after a short delay
      setTimeout(() => {
        const delayedId = getTweetIdFromElement(tweetElement);
        if (delayedId) {
          if (removedTweetIds.has(delayedId)) {
            if (tweetElement.parentElement) {
              removeTweetElement(tweetElement);
            }
          } else if (mutedTweetIds.has(delayedId) && !tweetElement.hasAttribute('data-iq-manually-revealed')) {
            if (!tweetElement.hasAttribute('data-iq-muted')) {
              muteTweetElement(tweetElement);
            }
          }
        }
      }, 50);
      return false;
    }

    // If tweet was previously removed, remove it immediately
    if (removedTweetIds.has(tweetId)) {
      // Mark as removed to prevent any processing
      tweetElement.setAttribute('data-iq-removed', 'true');
      if (tweetElement.parentElement) {
        removeTweetElement(tweetElement);
      }
      return true;
    }

    // If tweet was previously muted, mute it immediately
    if (mutedTweetIds.has(tweetId) && !tweetElement.hasAttribute('data-iq-manually-revealed')) {
      // Apply mute (this will also mark it and prevent processing)
      // Don't set attribute first - let muteTweetElement handle it
      muteTweetElement(tweetElement);
      return true;
    }

    // Not filtered, allow processing
    tweetElement.removeAttribute('data-iq-filtered');
    tweetElement.removeAttribute('data-iq-processing');
    return false;
  }

  /**
   * Check if a tweet should be skipped because it was previously removed or muted
   * @param {HTMLElement} tweetElement - The tweet element to check
   * @returns {boolean} True if the tweet should be skipped
   */
  function shouldSkipTweet(tweetElement) {
    if (!tweetElement) {
      return false;
    }

    // If already marked as filtered/removed/muted, skip immediately
    if (tweetElement.hasAttribute('data-iq-filtered') ||
        tweetElement.hasAttribute('data-iq-removed') ||
        (tweetElement.hasAttribute('data-iq-muted') && !tweetElement.hasAttribute('data-iq-manually-revealed'))) {
      return true;
    }

    const tweetId = getTweetIdFromElement(tweetElement);
    if (!tweetId) {
      return false;
    }

    // Skip if tweet was previously removed
    if (removedTweetIds.has(tweetId)) {
      // If tweet reappeared, remove it again immediately
      tweetElement.setAttribute('data-iq-removed', 'true');
      if (tweetElement.parentElement) {
        removeTweetElement(tweetElement);
      }
      return true;
    }

    // Skip if tweet was previously muted (unless manually revealed)
    if (mutedTweetIds.has(tweetId) && !tweetElement.hasAttribute('data-iq-manually-revealed')) {
      // If tweet reappeared and should still be muted, re-apply mute immediately
      tweetElement.setAttribute('data-iq-muted', 'true');
      if (!tweetElement.hasAttribute('data-iq-muted')) {
        muteTweetElement(tweetElement);
      }
      return true;
    }

    return false;
  }

  /**
   * Setup MutationObserver to intercept tweets BEFORE they can be processed
   * This runs independently and catches tweets as soon as they're added to DOM
   */
  function setupFilterObserver() {
    // Clean up existing observer if any
    if (filterObserver) {
      filterObserver.disconnect();
      filterObserver = null;
    }

    const settings = getSettings();
    if (!settings.enableIqFiltr) {
      return;
    }

    filterObserver = new MutationObserver((mutations) => {
      const potentialTweets = [];

      for (let i = 0; i < mutations.length; i++) {
        const mutation = mutations[i];
        for (let j = 0; j < mutation.addedNodes.length; j++) {
          const node = mutation.addedNodes[j];
          if (node.nodeType === Node.ELEMENT_NODE) {
            // Check if the added node is an article (tweet)
            if (node.tagName === 'ARTICLE') {
              potentialTweets.push(node);
            }
            // Check if the added node contains articles
            if (node.querySelector) {
              const articles = node.querySelectorAll('article');
              if (articles.length > 0) {
                for (let k = 0; k < articles.length; k++) {
                  potentialTweets.push(articles[k]);
                }
              }
            }
          }
        }
      }

      // Immediately intercept and filter any tweets that were previously removed/muted
      if (potentialTweets.length > 0) {
        // Use requestAnimationFrame to ensure DOM is ready, but run synchronously
        requestAnimationFrame(() => {
          potentialTweets.forEach((tweet) => {
            // Skip if already processed or intercepted
            if (tweet.hasAttribute('data-iq-analyzed') ||
                tweet.hasAttribute('data-iq-filtered') ||
                tweet.hasAttribute('data-iq-removed')) {
              return;
            }

            // Immediately intercept and filter
            interceptTweetImmediately(tweet);

            // Also check nested tweets
            const nestedTweet = tweet.querySelector('article[data-testid="tweet"]') ||
                               tweet.querySelector('article[role="article"]');
            if (nestedTweet && nestedTweet !== tweet) {
              if (!nestedTweet.hasAttribute('data-iq-analyzed') &&
                  !nestedTweet.hasAttribute('data-iq-filtered') &&
                  !nestedTweet.hasAttribute('data-iq-removed')) {
                interceptTweetImmediately(nestedTweet);
              }
            }
          });
        });
      }
    });

    // Start observing immediately
    if (document.body) {
      filterObserver.observe(document.body, {
        childList: true,
        subtree: true
      });
    }
  }

  /**
   * Stop the filter observer
   */
  function stopFilterObserver() {
    if (filterObserver) {
      filterObserver.disconnect();
      filterObserver = null;
    }
  }

  /**
   * Check and filter a tweet based on its IQ score and confidence
   * This should be called immediately after IQ calculation, before any animations
   * @param {HTMLElement} tweetElement - The tweet element
   * @param {number} iq - The IQ score
   * @param {number|null} confidence - The confidence percentage (0-100)
   * @returns {Promise<boolean>} True if the tweet was filtered (removed or muted)
   */
  async function checkAndFilter(tweetElement, iq, confidence) {
    if (!tweetElement) {
      return false;
    }

    // Check if tweet is invalid (IQ X) - handle separately
    const isInvalid = tweetElement.hasAttribute('data-iq-invalid') ||
                      iq === null ||
                      iq === undefined ||
                      (tweetElement.querySelector && tweetElement.querySelector('.iq-badge-invalid'));

    // If invalid, still check if we should filter it
    if (isInvalid) {
      const shouldFilter = await shouldFilterTweet(tweetElement, iq, confidence);
      if (shouldFilter) {
        const settings = getSettings();
        if (settings.filterMode === 'mute') {
          // For invalid tweets, we don't have valid IQ data, so use generic message
          await muteTweetElement(tweetElement);
        } else {
          await removeTweetElement(tweetElement);
        }
        return true;
      }
      return false;
    }

    // For valid tweets, require iq to be a number
    if (iq === null || iq === undefined) {
      return false;
    }

    const shouldFilter = await shouldFilterTweet(tweetElement, iq, confidence);
    const settings = getSettings();

    if (shouldFilter) {
      // If tweet should be filtered, remove the manually-revealed flag if it exists
      // This allows tweets to be re-filtered when filter settings change
      if (tweetElement.hasAttribute('data-iq-manually-revealed')) {
        tweetElement.removeAttribute('data-iq-manually-revealed');
      }

      const filterMode = settings.filterMode || 'remove';

      if (filterMode === 'mute') {
        // Pass IQ and filter settings to show appropriate message
        const filterDirection = settings.filterDirection || 'below';
        const filterThreshold = settings.filterIQThreshold || 100;
        muteTweetElement(tweetElement, iq, filterDirection, filterThreshold);
      } else {
        removeTweetElement(tweetElement);
      }
      return true;
    } else {
      // If tweet should not be filtered, check if it's currently muted and reveal it
      // But only if it wasn't manually revealed (user might have changed settings)
      // Note: We still respect manually-revealed flag when revealing, but we clear it
      // when filter settings change in applyFilterToVisibleTweets
      if (tweetElement.hasAttribute('data-iq-muted') && !tweetElement.hasAttribute('data-iq-manually-revealed')) {
        revealMutedTweet(tweetElement);
      }
    }

    return false;
  }

  /**
   * Apply filter to all currently visible tweets immediately
   * Called when filter settings change to apply filter without page refresh
   */
  async function applyFilterToVisibleTweets() {
    const settings = getSettings();

    // Only apply if filter is enabled
    if (!settings.enableIqFiltr) {
      return;
    }

    // Find all tweet elements that have IQ scores calculated
    const tweetSelectors = [
      'article[data-testid="tweet"]',
      'article[role="article"]',
      'div[data-testid="cellInnerDiv"] > article'
    ];

    let allTweets = [];
    for (const selector of tweetSelectors) {
      const tweets = document.querySelectorAll(selector);
      if (tweets.length > 0) {
        allTweets = Array.from(tweets);
        break;
      }
    }

    if (allTweets.length === 0) {
      allTweets = Array.from(document.querySelectorAll('article'));
    }

    // IMPORTANT: When filter settings change, clear the manually-revealed flag
    // from all tweets so they can be re-evaluated with the new filter criteria
    // This allows tweets that were previously revealed to be filtered again if they match
    allTweets.forEach(tweetElement => {
      if (tweetElement && tweetElement.hasAttribute('data-iq-manually-revealed')) {
        tweetElement.removeAttribute('data-iq-manually-revealed');
      }
    });

    let filteredCount = 0;
    let checkedCount = 0;

    // Check each tweet that has an IQ result
    for (const tweetElement of allTweets) {
      // Skip if already removed or doesn't exist
      if (!tweetElement || !tweetElement.parentElement) {
        continue;
      }

      // Check if this tweet has an IQ result stored
      const iqResult = tweetElement._iqResult;
      if (!iqResult || iqResult.iq === null || iqResult.iq === undefined) {
        // Try to get from badge if available
        const badge = tweetElement.querySelector('.iq-badge[data-iq-score]');
        if (badge) {
          const iqScore = badge.getAttribute('data-iq-score');
          const confidenceAttr = badge.getAttribute('data-confidence');

          if (iqScore && !isNaN(parseInt(iqScore, 10))) {
            const iq = parseInt(iqScore, 10);
            const confidence = confidenceAttr && !isNaN(parseInt(confidenceAttr, 10))
              ? parseInt(confidenceAttr, 10)
              : null;

            // Check and filter this tweet
            checkedCount++;
            const wasFiltered = await checkAndFilter(tweetElement, iq, confidence);
            if (wasFiltered) {
              filteredCount++;
            }
          }
        }
        continue;
      }

      // Check and filter this tweet using stored IQ result
      const iq = iqResult.iq;
      const confidence = iqResult.confidence !== null && iqResult.confidence !== undefined
        ? iqResult.confidence
        : null;

      checkedCount++;
      const wasFiltered = await checkAndFilter(tweetElement, iq, confidence);
      if (wasFiltered) {
        filteredCount++;
      }
    }

  }


  // Initialize filter observer when module loads
  // Wait for DOM to be ready
  if (typeof window !== 'undefined') {
    if (document.body) {
      // Check settings and setup observer if filter is enabled
      const settings = getSettings();
      if (settings && settings.enableIqFiltr) {
        setupFilterObserver();
      }
    } else {
      // Wait for DOM to be ready
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
          const settings = getSettings();
          if (settings && settings.enableIqFiltr) {
            setupFilterObserver();
          }
        });
      } else {
        setTimeout(() => {
          const settings = getSettings();
          if (settings && settings.enableIqFiltr) {
            setupFilterObserver();
          }
        }, 100);
      }
    }
  }

  // Export for use in other modules
  if (typeof window !== 'undefined') {
    window.IqFiltr = {
      checkAndFilter,
      shouldFilterTweet,
      isReply,
      isQuotedPost,
      isRegularTweet,
      removeTweetElement,
      muteTweetElement,
      revealMutedTweet,
      revealAllMutedTweets,
      applyFilterToVisibleTweets,
      shouldSkipTweet,
      getTweetIdFromElement,
      clearRemovedTweetIds,
      setupFilterObserver,
      stopFilterObserver,
      interceptTweetImmediately
    };
  }

})();

