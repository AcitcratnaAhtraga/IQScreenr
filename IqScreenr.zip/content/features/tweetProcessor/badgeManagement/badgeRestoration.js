/**
 * Badge Restoration Manager
 * Handles restoration of cached badges (cached guesses and IQ results)
 *
 * CRITICAL: This module prioritizes tweet-ID-based cache over handle-based cache.
 * Handle-based cache is shared across all tweets by the same user, which causes
 * all tweets on a profile page to show the same IQ. Tweet-ID-based cache is
 * specific to each tweet and should be used first.
 */

(function() {
  'use strict';

  // Get dependencies from other modules
  const getTextExtraction = () => window.TextExtraction || {};
  const getBadgeManager = () => window.BadgeManager || {};
  const getGameManager = () => window.GameManager || {};
  const getIQCache = () => window.IQCache || {};
  const getSettings = () => window.Settings || {};
  const getNotificationPlacement = () => window.NotificationBadgePlacement || {};
  const getNestedTweetHandler = () => window.NestedTweetHandler || {};
  const getBadgeUpdate = () => window.BadgeUpdate || {};

  /**
   * Place a restored badge in the correct location
   *
   * @param {HTMLElement} iqBadge - The badge element to place
   * @param {HTMLElement} actualTweetElement - The actual tweet element
   * @param {HTMLElement} outerElement - The outer wrapper element (if nested)
   * @param {boolean} hasNestedStructure - Whether this is a nested structure
   * @param {boolean} isNotificationsPage - Whether we're on the notifications page
   */
  function placeRestoredBadge(iqBadge, actualTweetElement, outerElement, hasNestedStructure, isNotificationsPage) {
    const { findNotificationBadgePlacement } = getNotificationPlacement() || {};
    const { getPlacementTarget } = getNestedTweetHandler();

    if (isNotificationsPage) {
      const placementTarget = getPlacementTarget(actualTweetElement, outerElement, hasNestedStructure, isNotificationsPage);
      const placement = findNotificationBadgePlacement ? findNotificationBadgePlacement(placementTarget) : null;
      if (placement) {
        const { targetElement, parentElement } = placement;
        if (placement.placement === 'before-tweet-content') {
          parentElement.insertBefore(iqBadge, targetElement);
        } else {
          if (targetElement.nextSibling) {
            parentElement.insertBefore(iqBadge, targetElement.nextSibling);
          } else {
            parentElement.appendChild(iqBadge);
          }
        }
      } else {
        actualTweetElement.insertBefore(iqBadge, actualTweetElement.firstChild);
      }
    } else {
      const engagementBar = actualTweetElement.querySelector('[role="group"]');
      if (engagementBar) {
        // Wrap badge in a container div to match other engagement items structure
        // This ensures the badge takes equal space like reply, repost, like buttons
        const badgeContainer = document.createElement('div');
        badgeContainer.className = 'css-175oi2r r-18u37iz r-1h0z5md r-13awgt0';
        badgeContainer.setAttribute('data-iq-badge-container', 'true');
        badgeContainer.style.cssText = 'display: flex; align-items: center; justify-content: center; flex: 1 1 0%; min-width: 0;';
        badgeContainer.appendChild(iqBadge);
        
        const firstChild = engagementBar.firstElementChild;
        if (firstChild) {
          engagementBar.insertBefore(badgeContainer, firstChild);
        } else {
          engagementBar.appendChild(badgeContainer);
        }
      } else {
        const tweetContent = actualTweetElement.querySelector('div[data-testid="tweetText"]') ||
                            actualTweetElement.querySelector('div[lang]') ||
                            actualTweetElement.firstElementChild;
        if (tweetContent && tweetContent.parentElement) {
          tweetContent.parentElement.insertBefore(iqBadge, tweetContent);
        } else {
          actualTweetElement.insertBefore(iqBadge, actualTweetElement.firstChild);
        }
      }
    }
  }

  /**
   * Restore badge from revealed IQ (cached revealed IQ result)
   *
   * @param {HTMLElement} actualTweetElement - The actual tweet element
   * @param {HTMLElement} outerElement - The outer wrapper element (if nested)
   * @param {boolean} hasNestedStructure - Whether this is a nested structure
   * @param {string} tweetId - The tweet ID
   * @param {boolean} isNotificationsPage - Whether we're on the notifications page
   * @param {Set} processedTweets - Set of processed tweets to update
   * @returns {boolean} Whether a badge was restored
   */
  async function restoreFromRevealedIQ(actualTweetElement, outerElement, hasNestedStructure, tweetId, isNotificationsPage, processedTweets) {
    const settings = getSettings();
    if (!settings.showIQBadge) {
      return false;
    }

    // CRITICAL: Prevent concurrent restoration attempts (race condition protection)
    const restorationKey = `_iq-restoring-${tweetId}`;
    const restorationPromiseKey = `_iq-restoring-promise-${tweetId}`;
    
    // Get findExistingBadge early for use in race condition check
    const { findExistingBadge } = getNestedTweetHandler();
    
    // If restoration is already in progress, wait for it to complete
    if (actualTweetElement[restorationKey]) {
      const existingPromise = actualTweetElement[restorationPromiseKey];
      if (existingPromise && existingPromise instanceof Promise) {
        // Wait for existing restoration to complete and check result
        const result = await existingPromise;
        if (result) {
          // Restoration succeeded
          return true;
        }
        // Restoration failed, clear flag and proceed with new attempt
        delete actualTweetElement[restorationKey];
        delete actualTweetElement[restorationPromiseKey];
      } else {
        // No promise stored, but flag is set - restoration might have completed
        // Check if badge is already updated
        if (findExistingBadge) {
          const existingBadge = findExistingBadge(actualTweetElement, outerElement, hasNestedStructure);
          if (existingBadge && existingBadge.hasAttribute('data-iq-score')) {
            // Badge already updated, restoration completed
            return true;
          }
        }
        // Badge not updated yet, but flag is set - might be stuck
        // Clear flag and proceed with restoration
        delete actualTweetElement[restorationKey];
      }
    }
    
    // Create a promise for this restoration attempt
    // CRITICAL: Create promise first, then assign it to avoid "before initialization" error
    let restorationPromise;
    restorationPromise = (async () => {
      try {
        actualTweetElement[restorationKey] = true;
        actualTweetElement[restorationPromiseKey] = restorationPromise;

        const gameManager = getGameManager();
        if (!gameManager || !gameManager.getCachedRevealedIQResult) {
          delete actualTweetElement[restorationKey];
          delete actualTweetElement[restorationPromiseKey];
          return false;
        }

        // FIRST: Try to get IQ result directly by tweet ID (tweet-specific)
        const cachedIQResult = await gameManager.getCachedRevealedIQResult(tweetId);
        if (!cachedIQResult || !cachedIQResult.iq) {
          delete actualTweetElement[restorationKey];
          delete actualTweetElement[restorationPromiseKey];
          return false;
        }

        // Convert to expected format - merge result object if it exists
        const cachedIQ = {
          iq_estimate: cachedIQResult.iq,
          confidence: cachedIQResult.confidence,
          ...(cachedIQResult.result || {})
        };

        // CRITICAL: Do NOT fall back to handle-based cache when cachedRevealed is true
        // Handle-based cache is shared across all tweets by the same user, which causes
        // all tweets on a profile page to show the same IQ. If there's no tweet-ID-specific
        // cache, we should not restore the badge (it will show as a guess badge instead).
        // This prevents tweets that were calculated when IQGuessr was OFF from incorrectly
        // showing the handle-based cache result when IQGuessr is re-enabled.

        if (!cachedIQ || cachedIQ.iq_estimate === undefined) {
          delete actualTweetElement[restorationKey];
          delete actualTweetElement[restorationPromiseKey];
          return false;
        }

        // We have revealed IQ and cached IQ - restore calculated badge directly
        const badgeManager = getBadgeManager();
        if (!badgeManager || !badgeManager.createIQBadge) {
          delete actualTweetElement[restorationKey];
          delete actualTweetElement[restorationPromiseKey];
          return false;
        }

        const { extractTweetText } = getTextExtraction();

        const iq = Math.round(cachedIQ.iq_estimate);
        const confidence = cachedIQ.confidence ? Math.round(cachedIQ.confidence) : null;
        const tweetText = extractTweetText ? extractTweetText(actualTweetElement) : null;

        // CRITICAL: Check IqFiltr IMMEDIATELY after getting IQ, before restoring badge
        const getIqFiltr = () => window.IqFiltr || {};
        const { checkAndFilter } = getIqFiltr();
        if (checkAndFilter) {
          const elementToCheck = (hasNestedStructure && outerElement) ? outerElement : actualTweetElement;
          const wasFiltered = await checkAndFilter(elementToCheck, iq, confidence);
          if (wasFiltered) {
            // Element was removed, stop restoration
            delete actualTweetElement[restorationKey];
            delete actualTweetElement[restorationPromiseKey];
            return true;
          }
        }

        // Check if there's already a badge to replace (including loading badges)
        const existingBadge = findExistingBadge(actualTweetElement, outerElement, hasNestedStructure);
    
        // CRITICAL: If badge already exists, UPDATE it instead of skipping
        // This ensures cached badges are actually restored, not just marked as "restored"
        if (existingBadge) {
          // Check if it's already a calculated badge with the correct score
          const existingScore = existingBadge.getAttribute('data-iq-score');
          const existingConfidence = existingBadge.getAttribute('data-confidence');
          
          if (existingScore && parseInt(existingScore, 10) === iq && 
              existingConfidence && parseInt(existingConfidence, 10) === confidence) {
            // Badge already shows correct IQ - just mark as restored
            delete actualTweetElement[restorationKey];
            delete actualTweetElement[restorationPromiseKey];
            return true;
          }
          
          // Badge exists but is loading or has wrong score - UPDATE it
          // Store IQ result on element for reference
          actualTweetElement._iqResult = {
            iq: iq,
            result: cachedIQ,
            confidence: confidence,
            text: tweetText
          };

          // Use updateBadgeWithIQ to update the existing badge
          const { updateBadgeWithIQ } = getBadgeUpdate();
          if (updateBadgeWithIQ) {
            // Update the existing badge (whether it's loading or already calculated)
            // CRITICAL: Await the update to ensure it completes before clearing the flag
            await updateBadgeWithIQ(
              existingBadge,
              actualTweetElement,
              outerElement,
              hasNestedStructure,
              isNotificationsPage,
              iq,
              cachedIQ,
              confidence,
              tweetText,
              tweetId
            );
            // Clear restoration flag AFTER update completes
            delete actualTweetElement[restorationKey];
            delete actualTweetElement[restorationPromiseKey];
            return true;
          } else {
            // Fallback: replace badge directly
            if (existingBadge.parentElement) {
              existingBadge.remove();
            }
            const iqBadge = badgeManager.createIQBadge(iq, cachedIQ, tweetText);
            const cachedGuess = gameManager.getCachedGuess ? await gameManager.getCachedGuess(tweetId) : null;
            if (cachedGuess && cachedGuess.guess !== undefined) {
              iqBadge.setAttribute('data-iq-compared', 'true');
            }
            placeRestoredBadge(iqBadge, actualTweetElement, outerElement, hasNestedStructure, isNotificationsPage);
            delete actualTweetElement[restorationKey];
            delete actualTweetElement[restorationPromiseKey];
            return true;
          }
        }

      // Create a loading badge first, then animate it (matches normal flow)
      const { createLoadingBadge } = badgeManager;
      if (!createLoadingBadge) {
        // Fallback: create badge directly if loading badge creation not available
        const iqBadge = badgeManager.createIQBadge(iq, cachedIQ, tweetText);
        const cachedGuess = gameManager.getCachedGuess ? await gameManager.getCachedGuess(tweetId) : null;
        if (cachedGuess && cachedGuess.guess !== undefined) {
          iqBadge.setAttribute('data-iq-compared', 'true');
        }
        actualTweetElement._iqResult = {
          iq: iq,
          result: cachedIQ,
          confidence: confidence,
          text: tweetText
        };
        placeRestoredBadge(iqBadge, actualTweetElement, outerElement, hasNestedStructure, isNotificationsPage);
        delete actualTweetElement[restorationKey];
        delete actualTweetElement[restorationPromiseKey];
        return true;
      }

      const loadingBadge = createLoadingBadge();

      // Place the loading badge first
      placeRestoredBadge(loadingBadge, actualTweetElement, outerElement, hasNestedStructure, isNotificationsPage);

      // Store IQ result on element for reference
      actualTweetElement._iqResult = {
        iq: iq,
        result: cachedIQ,
        confidence: confidence,
        text: tweetText
      };

      // Use the same update flow as normal badges to trigger count-up animation
      const { updateBadgeWithIQ } = getBadgeUpdate();
      if (updateBadgeWithIQ) {
        // Wait a frame to ensure badge is in DOM, then await the update
        await new Promise(resolve => {
          requestAnimationFrame(async () => {
            await updateBadgeWithIQ(
              loadingBadge,
              actualTweetElement,
              outerElement,
              hasNestedStructure,
              isNotificationsPage,
              iq,
              cachedIQ,
              confidence,
              tweetText,
              tweetId
            );
            // Clear restoration flag after update completes
            delete actualTweetElement[restorationKey];
            delete actualTweetElement[restorationPromiseKey];
            resolve();
          });
        });
      } else {
        // Fallback: create badge directly if updateBadgeWithIQ not available
        if (loadingBadge.parentElement) {
          loadingBadge.remove();
        }
        const iqBadge = badgeManager.createIQBadge(iq, cachedIQ, tweetText);
        const cachedGuess = gameManager.getCachedGuess ? await gameManager.getCachedGuess(tweetId) : null;
        if (cachedGuess && cachedGuess.guess !== undefined) {
          iqBadge.setAttribute('data-iq-compared', 'true');
        }
        placeRestoredBadge(iqBadge, actualTweetElement, outerElement, hasNestedStructure, isNotificationsPage);
        delete actualTweetElement[restorationKey];
        delete actualTweetElement[restorationPromiseKey];
      }

      return true;
    } catch (error) {
      // Clear flags on error
      delete actualTweetElement[restorationKey];
      delete actualTweetElement[restorationPromiseKey];
      console.error('[BadgeRestoration] Error restoring badge:', error);
      return false;
    } finally {
      // Always clear promise reference
      delete actualTweetElement[restorationPromiseKey];
    }
    })();
    
    // Start the restoration and return the promise
    return await restorationPromise;
  }

  /**
   * Restore badge from cached guess + cached IQ (handle-based)
   *
   * @param {HTMLElement} actualTweetElement - The actual tweet element
   * @param {HTMLElement} outerElement - The outer wrapper element (if nested)
   * @param {boolean} hasNestedStructure - Whether this is a nested structure
   * @param {string} tweetId - The tweet ID
   * @param {string} handle - The tweet handle
   * @param {boolean} isNotificationsPage - Whether we're on the notifications page
   * @param {Set} processedTweets - Set of processed tweets to update
   * @returns {boolean} Whether a badge was restored
   */
  async function restoreFromCachedGuess(actualTweetElement, outerElement, hasNestedStructure, tweetId, handle, isNotificationsPage, processedTweets, expandedText) {
    const settings = getSettings();
    if (!settings.showIQBadge) {
      return false;
    }

    const gameManager = getGameManager();
    if (!gameManager || !gameManager.getCachedGuess) {
      return false;
    }

    const cachedGuess = await gameManager.getCachedGuess(tweetId);
    if (!cachedGuess || cachedGuess.guess === undefined) {
      return false;
    }

    // We have a cached guess - check if we have cached IQ to restore calculated badge
    const { getCachedIQ } = getIQCache();
    const { extractTweetHandle, extractTweetText } = getTextExtraction();

    if (!getCachedIQ || !extractTweetHandle) {
      return false;
    }

    let tweetHandle = handle;
    if (!tweetHandle) {
      tweetHandle = actualTweetElement.getAttribute('data-handle');
      if (!tweetHandle) {
        tweetHandle = extractTweetHandle(actualTweetElement);
        if (tweetHandle) {
          actualTweetElement.setAttribute('data-handle', tweetHandle);
        }
      }
    }

    if (!tweetHandle) {
      return false;
    }

    if (!getCachedIQ) {
      return false;
    }

    const cachedIQ = getCachedIQ(tweetHandle);
    if (!cachedIQ || cachedIQ.iq_estimate === undefined) {
      return false;
    }

    // CRITICAL: Validate cache against expanded text before restoring
    // If cache was calculated with truncated text but we now have expanded text, invalidate cache
    if (cachedIQ && expandedText) {
      const cachedTextLength = cachedIQ.text_length;
      const currentTextLength = expandedText.length;
      
      // If text_length is missing from cache, it's an old cache entry (before we stored text_length)
      // If current text is significantly longer (>50 chars), it's likely expanded, so invalidate
      if (cachedTextLength === undefined && currentTextLength > 300) {
        return false;
      }
      
      // If text lengths differ significantly (>5 chars), cache is stale (calculated with truncated text)
      if (cachedTextLength !== undefined && Math.abs(cachedTextLength - currentTextLength) > 5) {
        // Don't restore - let it recalculate with expanded text
        return false;
      }
    }

    // We have both cached guess and cached IQ - restore calculated badge directly
    const badgeManager = getBadgeManager();
    if (!badgeManager || !badgeManager.createIQBadge) {
      return false;
    }

    const { findExistingBadge } = getNestedTweetHandler();

    const iq = Math.round(cachedIQ.iq_estimate);
    const confidence = cachedIQ.confidence ? Math.round(cachedIQ.confidence) : null;
    const tweetText = extractTweetText ? extractTweetText(actualTweetElement) : null;

    // CRITICAL: Check IqFiltr IMMEDIATELY after getting IQ, before restoring badge
    const getIqFiltr = () => window.IqFiltr || {};
    const { checkAndFilter } = getIqFiltr();
    if (checkAndFilter) {
      const elementToCheck = (hasNestedStructure && outerElement) ? outerElement : actualTweetElement;
      const wasFiltered = await checkAndFilter(elementToCheck, iq, confidence);
      if (wasFiltered) {
        // Element was removed, stop restoration
        return true;
      }
    }

    const iqBadge = badgeManager.createIQBadge(iq, cachedIQ, tweetText);

    // Mark badge as compared since there's a cached guess (meaning it was compared)
    iqBadge.setAttribute('data-iq-compared', 'true');

    // Store IQ result on element for reference (guess is already cached persistently)
    actualTweetElement._iqResult = {
      iq: iq,
      result: cachedIQ,
      confidence: confidence,
      text: tweetText
    };

    // Check if there's already a badge to replace
    const existingBadge = findExistingBadge(actualTweetElement, outerElement, hasNestedStructure);

    // Place the badge
    placeRestoredBadge(iqBadge, actualTweetElement, outerElement, hasNestedStructure, isNotificationsPage);

    // Remove existing badge if it exists
    if (existingBadge && existingBadge.parentElement) {
      existingBadge.remove();
    }

    return true;
  }

  /**
   * Try to restore cached badge (either from revealed IQ or cached guess)
   *
   * @param {HTMLElement} actualTweetElement - The actual tweet element
   * @param {HTMLElement} outerElement - The outer wrapper element (if nested)
   * @param {boolean} hasNestedStructure - Whether this is a nested structure
   * @param {string} tweetId - The tweet ID
   * @param {string} handle - The tweet handle
   * @param {boolean} isNotificationsPage - Whether we're on the notifications page
   * @param {Set} processedTweets - Set of processed tweets to update
   * @returns {boolean} Whether a badge was restored (and processing should stop)
   */
  async function tryRestoreBadge(actualTweetElement, outerElement, hasNestedStructure, tweetId, handle, isNotificationsPage, processedTweets, expandedText) {
    const settings = getSettings();
    if (!settings.showIQBadge) {
      return false;
    }

    const gameManager = getGameManager();
    if (!gameManager) {
      return false;
    }

    // Check if IQGuessr is enabled - if not, still check for cached revealed IQ to restore badges
    const isGameModeEnabled = gameManager.isGameModeEnabled && gameManager.isGameModeEnabled();

    if (!tweetId) {
      return false;
    }

    // FIRST: Check if IQ was previously revealed (either with or without a guess), show as calculated
    // This works even when IQGuessr is disabled - badges with cached IQ should still be restored
    const cachedRevealed = gameManager.getCachedRevealedIQ ? await gameManager.getCachedRevealedIQ(tweetId) : false;

    if (cachedRevealed) {
      // CRITICAL: Validate cache against expanded text before restoring
      // If cache was calculated with truncated text but we now have expanded text, invalidate cache
      const cachedIQResult = await gameManager.getCachedRevealedIQResult(tweetId);
      
      if (cachedIQResult && cachedIQResult.result && expandedText) {
        const cachedTextLength = cachedIQResult.result.text_length;
        const currentTextLength = expandedText.length;
        
        // If text_length is missing from cache, it's an old cache entry (before we stored text_length)
        // If current text is significantly longer (>50 chars), it's likely expanded, so invalidate
        if (cachedTextLength === undefined && currentTextLength > 300) {
          return false;
        }
        
        // If text lengths differ significantly (>5 chars), cache is stale (calculated with truncated text)
        if (cachedTextLength !== undefined && Math.abs(cachedTextLength - currentTextLength) > 5) {
          // Don't restore - let it recalculate with expanded text
          return false;
        }
      }
      
      // Try to restore from revealed IQ (tweet-ID-based cache)
      const tracker = window.BadgeStateTracker || {};
      if (tracker.logTweetBadgeState) {
        const tweetElement = actualTweetElement.closest('article[data-testid="tweet"]') ||
                             actualTweetElement.closest('article[role="article"]') ||
                             actualTweetElement;
        await tracker.logTweetBadgeState(tweetElement, 'restoreFromRevealedIQ-attempt');
      }
      
      const restored = await restoreFromRevealedIQ(actualTweetElement, outerElement, hasNestedStructure, tweetId, isNotificationsPage, processedTweets);
      if (restored) {
        // Debug logging: Restoration successful
        if (tracker.logTweetBadgeState) {
          const tweetElement = actualTweetElement.closest('article[data-testid="tweet"]') ||
                               actualTweetElement.closest('article[role="article"]') ||
                               actualTweetElement;
          await tracker.logTweetBadgeState(tweetElement, 'restoreFromRevealedIQ-success');
        }
        
        // Mark as analyzed and return early (skip calculation and all other processing)
        const { markAsAnalyzed } = getNestedTweetHandler();
        markAsAnalyzed(actualTweetElement, outerElement, hasNestedStructure, processedTweets);
        actualTweetElement.removeAttribute('data-iq-processing');
        actualTweetElement.removeAttribute('data-iq-processing-start');
        return true;
      } else {
        // Debug logging: Restoration failed
        if (tracker.logTweetBadgeState) {
          const tweetElement = actualTweetElement.closest('article[data-testid="tweet"]') ||
                               actualTweetElement.closest('article[role="article"]') ||
                               actualTweetElement;
          await tracker.logTweetBadgeState(tweetElement, 'restoreFromRevealedIQ-failed');
        }
      }
    }

    // SECOND: Try to restore from cached guess + handle-based IQ cache
    // Only do this when IQGuessr is enabled (otherwise no guess badges should be shown)
    if (isGameModeEnabled) {
      const restored = await restoreFromCachedGuess(actualTweetElement, outerElement, hasNestedStructure, tweetId, handle, isNotificationsPage, processedTweets, expandedText);
      if (restored) {
        // Mark as analyzed and return early (skip calculation and all other processing)
        const { markAsAnalyzed } = getNestedTweetHandler();
        markAsAnalyzed(actualTweetElement, outerElement, hasNestedStructure, processedTweets);
        actualTweetElement.removeAttribute('data-iq-processing');
        actualTweetElement.removeAttribute('data-iq-processing-start');
        return true;
      }
    }

    return false;
  }

  // Export for use in other modules
  if (typeof window !== 'undefined') {
    window.BadgeRestoration = {
      tryRestoreBadge,
      restoreFromRevealedIQ,
      restoreFromCachedGuess,
      placeRestoredBadge
    };
  }
})();

