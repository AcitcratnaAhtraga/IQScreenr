/**
 * IQGuessr Browser Extension - Main Content Script
 *
 * This is the orchestrator that coordinates all modules:
 * - Core: dependencyParser, iqEstimator
 * - Utils: cache, domHelpers, textExtraction, tweetDetection
 * - Features: settings, badge, tweetProcessor, realtime
 *
 * All modules are loaded via manifest.json in the correct order.
 */

(function() {
  'use strict';


  // Get module references (all modules expose themselves via window global objects)
  const getSettings = () => window.Settings || {};
  const getTweetProcessor = () => window.TweetProcessor || {};
  const getRealtimeManager = () => window.RealtimeManager || {};
  const getBadgeManager = () => window.BadgeManager || {};
  const getGameManager = () => window.GameManager || {};
  const getDebugLog = () => window.DOMHelpers?.debugLog || (() => {});
  const debugLog = getDebugLog();

  /**
   * Apply settings changes immediately
   */
  async function applySettingsChanges(changes) {
    const settings = getSettings();
    const tweetProcessor = getTweetProcessor();
    const realtimeManager = getRealtimeManager();
    const badgeManager = getBadgeManager();

    // Handle showIQBadge changes
    if (changes.showIQBadge !== undefined) {
      const showBadges = changes.showIQBadge.newValue;
      const allBadges = document.querySelectorAll('.iq-badge:not(.iq-badge-realtime)');

      if (showBadges) {
        // Show all badges
        allBadges.forEach(badge => {
          badge.style.setProperty('display', 'inline-flex', 'important');
          badge.style.setProperty('visibility', 'visible', 'important');
          badge.style.setProperty('opacity', '1', 'important');
        });
        // Don't reprocess - let observer handle new tweets
      } else {
        // Hide all badges
        allBadges.forEach(badge => {
          badge.style.setProperty('display', 'none', 'important');
          badge.style.setProperty('visibility', 'hidden', 'important');
        });
      }
    }

    // Handle showRealtimeBadge changes
    if (changes.showRealtimeBadge !== undefined) {
      const showRealtime = changes.showRealtimeBadge.newValue;
      const realtimeBadges = document.querySelectorAll('.iq-badge-realtime');

      if (showRealtime && settings.showIQBadge) {
        // Only show realtime badges that have text (updateRealtimeBadge handles showing/hiding based on text)
        // Don't force display - let updateRealtimeBadge control visibility based on whether user has typed
        realtimeBadges.forEach(badge => {
          // Check if badge has text by checking if it has an IQ score or is showing X
          const hasScore = badge.hasAttribute('data-iq-score');
          const scoreElement = badge.querySelector('.iq-score');
          const hasText = hasScore || (scoreElement && scoreElement.textContent && scoreElement.textContent.trim() !== '');

          // Only show if badge indicates user has typed (has score or shows X)
          if (hasText) {
            badge.style.setProperty('display', 'inline-flex', 'important');
            badge.style.setProperty('visibility', 'visible', 'important');
            badge.style.setProperty('opacity', '1', 'important');
          } else {
            // Hide if no text has been typed yet
            badge.style.setProperty('display', 'none', 'important');
          }
        });
        // Realtime feature is disabled - do not restart monitoring
        // if (realtimeManager && realtimeManager.setupRealtimeComposeObserver) {
        //   realtimeManager.setupRealtimeComposeObserver();
        // }
      } else {
        // Hide all realtime badges
        realtimeBadges.forEach(badge => {
          badge.remove();
        });
      }
    }

    // If showIQBadge is disabled, also hide realtime badges
    if (changes.showIQBadge !== undefined && !changes.showIQBadge.newValue) {
      const realtimeBadges = document.querySelectorAll('.iq-badge-realtime');
      realtimeBadges.forEach(badge => {
        badge.remove();
      });
    }

    // Handle useConfidenceForColor changes - update existing badge colors
    if (changes.useConfidenceForColor !== undefined) {
      const useConfidence = changes.useConfidenceForColor.newValue;
      const { getIQColor, getConfidenceColor } = badgeManager;

      if (getIQColor && getConfidenceColor) {
        const allBadges = document.querySelectorAll('.iq-badge:not(.iq-badge-loading):not(.iq-badge-invalid)');
        allBadges.forEach(badge => {
          const iqScore = badge.getAttribute('data-iq-score');
          const confidence = badge.getAttribute('data-confidence');

          if (iqScore && !isNaN(parseInt(iqScore, 10))) {
            const iq = parseInt(iqScore, 10);
            const newColor = useConfidence && confidence
              ? getConfidenceColor(parseInt(confidence, 10))
              : getIQColor(iq);
            // Use CSS variable instead of inline style - CSS handles styling
            badge.style.setProperty('--iq-badge-bg-color', newColor);
            if (badge.classList.contains('iq-badge-flip')) {
              badge.style.setProperty('--iq-badge-original-bg', newColor, 'important');
            }
          }
        });
      }
    }

    // Handle IqFiltr settings changes - apply filter immediately
    const filterSettings = [
      'enableIqFiltr',
      'filterUserPosts',
      'filterIQThreshold',
      'filterDirection',
      'filterConfidenceThreshold',
      'filterConfidenceDirection',
      'useIQInFilter',
      'useConfidenceInFilter',
      'filterInvalidTweets',
      'filterMode'
    ];

    const hasFilterChange = filterSettings.some(setting => changes[setting] !== undefined);
    if (hasFilterChange) {
      const settings = getSettings();
      const debugLogging = settings.enableDebugLogging;


      const getIqFiltr = () => window.IqFiltr || {};
      const { applyFilterToVisibleTweets, revealAllMutedTweets, setupFilterObserver, stopFilterObserver } = getIqFiltr();

      // If filter is being disabled, reveal all muted tweets and clear removed tweet IDs
      if (changes.enableIqFiltr && !changes.enableIqFiltr.newValue) {
        const { clearRemovedTweetIds } = getIqFiltr();
        if (revealAllMutedTweets) {
          revealAllMutedTweets();
        }
        if (clearRemovedTweetIds) {
          clearRemovedTweetIds();
        }
        // Stop the filter observer when filter is disabled
        if (stopFilterObserver) {
          stopFilterObserver();
        }
      } else if (changes.enableIqFiltr && changes.enableIqFiltr.newValue) {
        // Filter is being enabled - start the observer
        if (setupFilterObserver) {
          setupFilterObserver();
        }
        if (applyFilterToVisibleTweets) {
          // Apply filter immediately when settings change
          requestAnimationFrame(() => {
            applyFilterToVisibleTweets();
          });
        }
      } else if (applyFilterToVisibleTweets) {
        // Apply filter immediately when settings change
        // Use requestAnimationFrame to ensure settings are updated and DOM is ready
        requestAnimationFrame(() => {
          applyFilterToVisibleTweets();
        });
      }

      // If filter mode changed from 'mute' to 'remove', remove all currently muted tweets that match filter
      if (changes.filterMode && changes.filterMode.oldValue === 'mute' && changes.filterMode.newValue === 'remove') {
        if (applyFilterToVisibleTweets) {
          requestAnimationFrame(() => {
            applyFilterToVisibleTweets();
          });
        }
      }
    }

    // Handle minIQ/maxIQ changes - hide/show badges based on range
    if (changes.minIQ !== undefined || changes.maxIQ !== undefined) {
      const minIQ = settings.minIQ || 60;
      const maxIQ = settings.maxIQ || 145;
      const allBadges = document.querySelectorAll('.iq-badge:not(.iq-badge-loading):not(.iq-badge-invalid)');

      allBadges.forEach(badge => {
        const iqScore = badge.getAttribute('data-iq-score');
        if (iqScore && !isNaN(parseInt(iqScore, 10))) {
          const iq = parseInt(iqScore, 10);
          if (iq < minIQ || iq > maxIQ) {
            badge.style.setProperty('display', 'none', 'important');
          } else {
            // Only show if showIQBadge is enabled
            if (settings.showIQBadge) {
              badge.style.setProperty('display', 'inline-flex', 'important');
              badge.style.setProperty('visibility', 'visible', 'important');
            }
          }
        }
      });
    }

    // Handle enableIQGuessr changes - convert badges between loading and guess modes
    if (changes.enableIQGuessr !== undefined) {
      const gameModeEnabled = changes.enableIQGuessr.newValue;
      const gameManager = getGameManager();
      const badgeManager = getBadgeManager();


      if (!gameModeEnabled && badgeManager && badgeManager.createLoadingBadge) {
        // Game mode disabled: convert guess badges back to loading badges
        
        // Debug logging: Log mode change
        const tracker = window.BadgeStateTracker || {};
        if (tracker.logAllTweetsInViewport) {
          console.log('[Content] Mode changed to Normal - logging all tweets before conversion');
          tracker.logAllTweetsInViewport();
        }

        const guessBadges = Array.from(document.querySelectorAll('.iq-badge-guess, [data-iq-guess="true"]'));
        
        // CRITICAL: Process all guess badges and ensure they're all removed before creating loading badges
        // This prevents race conditions where some badges might still exist during reprocessing
        const tweetsToReprocess = new Set();
        
        guessBadges.forEach(guessBadge => {
          // Only convert badges that haven't been guessed yet
          if (!guessBadge.hasAttribute('data-iq-guessed') && !guessBadge.hasAttribute('data-iq-calculating')) {
            // Find the tweet element containing this badge
            const tweetElement = guessBadge.closest('article[data-testid="tweet"]') ||
                                guessBadge.closest('article[role="article"]') ||
                                guessBadge.closest('article');

            if (!tweetElement) return;

            const tweetId = tweetElement?.getAttribute('data-tweet-id');
            
            // Find nested tweet if it exists
            const nestedTweet = tweetElement.querySelector('article[data-testid="tweet"]') ||
                               tweetElement.querySelector('article[role="article"]');
            const actualTweetElement = nestedTweet && nestedTweet !== tweetElement ? nestedTweet : tweetElement;

            // Debug logging: Log badge conversion
            if (tracker.logBadgeStateChange && tweetElement) {
              const fromState = tracker.getBadgeState ? tracker.getBadgeState(guessBadge) : null;
              tracker.logBadgeStateChange(guessBadge, fromState, null, 'mode-switch-to-loading');
            }

            // CRITICAL: Remove ALL guess badges for this tweet first (prevent duplicates)
            const allGuessBadges = [
              ...actualTweetElement.querySelectorAll('.iq-badge-guess'),
              ...actualTweetElement.querySelectorAll('[data-iq-guess="true"]'),
              ...(nestedTweet && nestedTweet !== tweetElement ? [
                ...tweetElement.querySelectorAll('.iq-badge-guess'),
                ...tweetElement.querySelectorAll('[data-iq-guess="true"]')
              ] : [])
            ].filter((badge, index, self) => index === self.findIndex(b => b === badge));

            // Remove all guess badges
            allGuessBadges.forEach(badge => {
              if (badge.parentElement) {
                badge.remove();
              }
            });

            // Create loading badge only if one doesn't already exist
            const existingLoadingBadge = actualTweetElement.querySelector('.iq-badge-loading, [data-iq-loading="true"]') ||
                                        (nestedTweet && nestedTweet !== tweetElement ? 
                                         tweetElement.querySelector('.iq-badge-loading, [data-iq-loading="true"]') : null);
            
            if (!existingLoadingBadge) {
              const loadingBadge = badgeManager.createLoadingBadge();
              
              // Find engagement bar for placement
              const engagementBar = actualTweetElement.querySelector('[role="group"]');
              if (engagementBar) {
                const firstChild = engagementBar.firstElementChild;
                if (firstChild) {
                  engagementBar.insertBefore(loadingBadge, firstChild);
                } else {
                  engagementBar.appendChild(loadingBadge);
                }
              } else {
                actualTweetElement.insertBefore(loadingBadge, actualTweetElement.firstChild);
              }

              // Debug logging: Log after conversion
              if (tracker.logBadgeStateChange && loadingBadge && tweetElement) {
                const toState = tracker.getBadgeState ? tracker.getBadgeState(loadingBadge) : null;
                tracker.logBadgeStateChange(loadingBadge, null, toState, 'mode-switch-to-loading-complete');
              }
            }

            // Mark the tweet for reprocessing
            tweetsToReprocess.add(actualTweetElement);
          }
        });

        // CRITICAL: Mark all tweets for reprocessing AFTER all conversions are complete
        tweetsToReprocess.forEach(actualTweetElement => {
          actualTweetElement.removeAttribute('data-iq-analyzed');
          actualTweetElement.removeAttribute('data-iq-processing');
          actualTweetElement.removeAttribute('data-iq-processing-start');

          // Remove from processed tweets Set to allow reprocessing
          const tweetProcessorModule = getTweetProcessor();
          if (tweetProcessorModule && tweetProcessorModule.processedTweets) {
            tweetProcessorModule.processedTweets.delete(actualTweetElement);
          }
        });

        // Reprocess visible tweets to trigger IQ calculations for converted badges
        if (tweetProcessor && tweetProcessor.processVisibleTweets) {
          setTimeout(() => {
            console.log('[Content] Reprocessing visible tweets after mode switch to Normal');
            tweetProcessor.processVisibleTweets();
            
            // Log all tweets after reprocessing
            if (tracker.logAllTweetsInViewport) {
              setTimeout(() => {
                console.log('[Content] Logging all tweets after reprocessing');
                tracker.logAllTweetsInViewport();
              }, 500);
            }
          }, 200);
        }
      } else if (gameModeEnabled && gameManager && gameManager.replaceLoadingBadgeWithGuess && settings.showIQBadge) {
        // Game mode enabled: convert loading badges to guess badges
        // PERFORMANCE OPTIMIZED: Batch conversions, parallel processing, cached DOM queries
        
        const loadingBadges = Array.from(document.querySelectorAll('.iq-badge-loading, [data-iq-loading="true"]'));
        
        // Debug logging: Defer to avoid blocking (only if enabled)
        const tracker = window.BadgeStateTracker || {};
        const debugEnabled = tracker.logAllTweetsInViewport;
        const scheduleIdle = typeof requestIdleCallback !== 'undefined' 
          ? requestIdleCallback 
          : (fn, opts) => setTimeout(fn, opts?.timeout || 100);
        
        if (debugEnabled) {
          scheduleIdle(() => {
            console.log('[Content] Mode changed to IqGuessr - logging all tweets before conversion');
            tracker.logAllTweetsInViewport();
          }, { timeout: 1000 });
        }

        // OPTIMIZATION: Cache tweet element lookups and batch DOM operations
        const badgeData = new Map(); // Map<badge, {tweetElement, actualTweetElement, tweetId}>
        const processedTweetsForDupes = new Set();
        
        // First pass: Cache all DOM queries and clean up duplicates
        for (const loadingBadge of loadingBadges) {
          const tweetElement = loadingBadge.closest('article[data-testid="tweet"]') ||
                              loadingBadge.closest('article[role="article"]') ||
                              loadingBadge.closest('article');
          
          if (!tweetElement) continue;
          
          if (!processedTweetsForDupes.has(tweetElement)) {
            processedTweetsForDupes.add(tweetElement);
            
            // Find nested tweet if it exists (cache this lookup)
            const nestedTweet = tweetElement.querySelector('article[data-testid="tweet"]') ||
                               tweetElement.querySelector('article[role="article"]');
            const actualTweetElement = nestedTweet && nestedTweet !== tweetElement ? nestedTweet : tweetElement;

            // Find all badges in this tweet (single query)
            const allBadges = actualTweetElement.querySelectorAll('.iq-badge');
            
            // Remove duplicates (keep the first one)
            if (allBadges.length > 1) {
              // Use DocumentFragment for batch removal
              for (let i = 1; i < allBadges.length; i++) {
                if (allBadges[i].parentElement) {
                  allBadges[i].remove();
                }
              }
            }
          }
          
          // Cache tweet element data for this badge
          const nestedTweet = tweetElement.querySelector('article[data-testid="tweet"]') ||
                             tweetElement.querySelector('article[role="article"]');
          const actualTweetElement = nestedTweet && nestedTweet !== tweetElement ? nestedTweet : tweetElement;
          const tweetId = actualTweetElement.getAttribute('data-tweet-id');
          
          badgeData.set(loadingBadge, {
            tweetElement,
            actualTweetElement,
            tweetId
          });
        }

        // OPTIMIZATION: Batch badge conversions in parallel (process all at once)
        const conversionPromises = [];
        const tweetProcessorModule = getTweetProcessor();
        
        for (const loadingBadge of badgeData.keys()) {
          // Only convert badges that are still loading
          if (!loadingBadge.hasAttribute('data-iq-loading') && 
              !loadingBadge.classList.contains('iq-badge-loading')) {
            continue;
          }
          
          const { tweetElement, actualTweetElement, tweetId } = badgeData.get(loadingBadge);
          
          // ANTI-CHEAT: Check if this tweet already has a cached revealed IQ
          // If it does, keep it as a calculated badge instead of converting to guess badge
          // This prevents users from toggling game mode on/off to see answers
          const cachedRevealedIQ = gameManager.getCachedRevealedIQResult ? 
            await gameManager.getCachedRevealedIQResult(tweetId) : null;
          
          if (cachedRevealedIQ && cachedRevealedIQ.iq) {
            // Tweet already has calculated IQ - skip conversion, keep as calculated badge
            // Mark as analyzed to prevent reprocessing
            if (actualTweetElement) {
              actualTweetElement.setAttribute('data-iq-analyzed', 'true');
            }
            continue; // Skip converting this badge
          }
          
          // Convert badge (don't await - process in parallel)
          const conversionPromise = (async () => {
            try {
              // Debug logging: Only log if enabled (defer to avoid blocking)
              if (debugEnabled && tracker.logBadgeStateChange) {
                scheduleIdle(() => {
                  const fromState = tracker.getBadgeState ? tracker.getBadgeState(loadingBadge) : null;
                  tracker.logBadgeStateChange(loadingBadge, fromState, null, 'mode-switch-to-guess');
                }, { timeout: 100 });
              }

              const guessBadge = await gameManager.replaceLoadingBadgeWithGuess(loadingBadge);

              // Mark tweet for reprocessing (synchronous DOM operations)
              if (actualTweetElement) {
                actualTweetElement.removeAttribute('data-iq-analyzed');
                actualTweetElement.removeAttribute('data-iq-processing');
                actualTweetElement.removeAttribute('data-iq-processing-start');

                if (tweetProcessorModule && tweetProcessorModule.processedTweets) {
                  tweetProcessorModule.processedTweets.delete(actualTweetElement);
                }
              }

              // Debug logging: Defer
              if (debugEnabled && tracker.logBadgeStateChange && guessBadge) {
                scheduleIdle(() => {
                  const toState = tracker.getBadgeState ? tracker.getBadgeState(guessBadge) : null;
                  tracker.logBadgeStateChange(guessBadge, null, toState, 'mode-switch-to-guess-complete');
                }, { timeout: 100 });
              }
            } catch (error) {
              console.error('[Content] Error converting badge:', error);
            }
          })();
          
          conversionPromises.push(conversionPromise);
        }

        // Wait for all conversions to complete (but don't block UI)
        Promise.all(conversionPromises).then(() => {
          // Reprocess visible tweets after all conversions complete
          if (tweetProcessor && tweetProcessor.processVisibleTweets) {
            requestAnimationFrame(() => {
              tweetProcessor.processVisibleTweets();
              
              // Debug logging: Defer
              if (debugEnabled && tracker.logAllTweetsInViewport) {
                scheduleIdle(() => {
                  console.log('[Content] Logging all tweets after reprocessing');
                  tracker.logAllTweetsInViewport();
                }, { timeout: 1000 });
              }
            });
          }
        }).catch(error => {
          console.error('[Content] Error during badge conversion:', error);
        });
      }
    }
  }

  /**
   * Attach click handlers to existing badges to prevent navigation
   */
  function attachBadgeClickHandlers() {
    const badges = document.querySelectorAll('.iq-badge:not(.iq-badge-realtime)');
    badges.forEach(badge => {
      // Skip if handler already attached
      if (badge.hasAttribute('data-click-handler-attached')) {
        return;
      }

      // Skip guess badges - they already have their own handlers
      const isGuessBadge = badge.classList.contains('iq-badge-guess') || badge.hasAttribute('data-iq-guess');
      if (isGuessBadge) {
        return;
      }

      // Skip average IQ badges - they use CSS-only hover effects
      const isAverageBadge = badge.classList.contains('iq-badge-average') || badge.hasAttribute('data-iq-average');
      if (isAverageBadge) {
        return;
      }

      badge.setAttribute('data-click-handler-attached', 'true');

      const handleBadgeInteraction = (e) => {
        // Prevent navigation to tweet URL
        e.preventDefault();
        e.stopPropagation();

        // Only handle flip animation for badges with confidence data
        if (badge.classList.contains('iq-badge-flip')) {
          const inner = badge.querySelector('.iq-badge-inner');
          if (inner) {
            const currentTransform = window.getComputedStyle(inner).transform;
            const isFlipped = currentTransform && currentTransform !== 'none' && currentTransform.includes('180deg');

            // Toggle flip state
            if (isFlipped) {
              inner.style.setProperty('transform', 'rotateY(0deg)', 'important');
            } else {
              inner.style.setProperty('transform', 'rotateY(180deg)', 'important');
            }

            // Auto-flip back after 2 seconds on mobile
            setTimeout(() => {
              if (inner.style.transform.includes('180deg')) {
                inner.style.setProperty('transform', 'rotateY(0deg)', 'important');
              }
            }, 2000);
          }
        }
      };

      // Add both click and touchend handlers for mobile compatibility
      badge.addEventListener('click', handleBadgeInteraction, true);
      badge.addEventListener('touchend', (e) => {
        handleBadgeInteraction(e);
        // Also prevent the click event that follows touchend
        e.preventDefault();
      }, { passive: false, capture: true });
    });
  }

  /**
   * Apply IQGuessr mode on page load if enabled
   */
  async function applyIQGuessrModeOnLoad() {
    const settings = getSettings();
    const gameManager = getGameManager();
    const badgeManager = getBadgeManager();

    if (!settings.showIQBadge) {
      return;
    }

    if (settings.enableIQGuessr && gameManager && gameManager.replaceLoadingBadgeWithGuess && badgeManager) {
      // Game mode enabled on page load - convert loading badges to guess badges
      const loadingBadges = document.querySelectorAll('.iq-badge-loading, [data-iq-loading="true"]');

      // First, clean up duplicate badges for each tweet
      const processedTweetsForDupes = new Set();
      for (const loadingBadge of loadingBadges) {
        const tweetElement = loadingBadge.closest('article[data-testid="tweet"]') ||
                            loadingBadge.closest('article[role="article"]') ||
                            loadingBadge.closest('article');
        if (tweetElement && !processedTweetsForDupes.has(tweetElement)) {
          processedTweetsForDupes.add(tweetElement);
          // Find nested tweet if it exists
          const nestedTweet = tweetElement.querySelector('article[data-testid="tweet"]') ||
                             tweetElement.querySelector('article[role="article"]');
          const actualTweetElement = nestedTweet && nestedTweet !== tweetElement ? nestedTweet : tweetElement;

          // Find all badges in this tweet
          const allBadges = [
            ...actualTweetElement.querySelectorAll('.iq-badge'),
            ...(nestedTweet && nestedTweet !== tweetElement ? tweetElement.querySelectorAll('.iq-badge') : [])
          ];

          // Remove duplicates (keep the first one)
          if (allBadges.length > 1) {
            for (let i = 1; i < allBadges.length; i++) {
              if (allBadges[i].parentElement) {
                allBadges[i].remove();
              }
            }
          }
        }
      }

      // Get loading badges again after cleanup
      const loadingBadgesAfterCleanup = document.querySelectorAll('.iq-badge-loading, [data-iq-loading="true"]');
      for (const loadingBadge of loadingBadgesAfterCleanup) {
        // Only convert badges that are still loading (not yet calculated)
        if (loadingBadge.hasAttribute('data-iq-loading') || loadingBadge.classList.contains('iq-badge-loading')) {
          const tweetElement = loadingBadge.closest('article[data-testid="tweet"]') ||
                              loadingBadge.closest('article[role="article"]') ||
                              loadingBadge.closest('article');
          const tweetId = tweetElement?.getAttribute('data-tweet-id');

          await gameManager.replaceLoadingBadgeWithGuess(loadingBadge);

        }
      }

      // Final cleanup pass: remove any remaining duplicate guess badges across all tweets
      const allTweets = document.querySelectorAll('article[data-testid="tweet"], article[role="article"]');
      const processedTweetsForFinalCleanup = new Set();
      for (const tweet of allTweets) {
        const tweetId = tweet.getAttribute('data-tweet-id');
        if (tweetId && !processedTweetsForFinalCleanup.has(tweetId)) {
          processedTweetsForFinalCleanup.add(tweetId);
          // Use the cleanup function if available
          if (gameManager.cleanupDuplicateGuessBadges) {
            gameManager.cleanupDuplicateGuessBadges(tweet);
          }
        }
      }

      // Also handle calculated badges that already exist
      // ANTI-CHEAT: These should stay as calculated badges if they have cached revealed IQ
      // This prevents users from toggling game mode on/off to see answers
      const calculatedBadges = document.querySelectorAll('.iq-badge[data-iq-score]:not([data-iq-guess]):not([data-iq-loading="true"])');
      for (const calculatedBadge of calculatedBadges) {
        const tweetElement = calculatedBadge.closest('article[data-testid="tweet"]') ||
                            calculatedBadge.closest('article[role="article"]') ||
                            calculatedBadge.closest('article');
        if (tweetElement) {
          const tweetId = tweetElement.getAttribute('data-tweet-id');
          if (tweetId) {
            // ANTI-CHEAT: Check for cached revealed IQ first (prevents cheating)
            const cachedRevealedIQ = gameManager.getCachedRevealedIQResult ? 
              await gameManager.getCachedRevealedIQResult(tweetId) : null;
            
            if (cachedRevealedIQ && cachedRevealedIQ.iq) {
              // Tweet has cached revealed IQ - keep as calculated badge (anti-cheat)
              debugLog('[Content] Keeping calculated badge with cached revealed IQ for tweet:', tweetId);
              // Mark as analyzed to prevent reprocessing
              const nestedTweet = tweetElement.querySelector('article[data-testid="tweet"]') ||
                                 tweetElement.querySelector('article[role="article"]');
              const actualTweetElement = nestedTweet && nestedTweet !== tweetElement ? nestedTweet : tweetElement;
              if (actualTweetElement) {
                actualTweetElement.setAttribute('data-iq-analyzed', 'true');
              }
            } else {
              // Check for cached guess as fallback
              const cachedGuess = await gameManager.getCachedGuess(tweetId);
              if (cachedGuess && cachedGuess.guess !== undefined) {
                // User has a cached guess, calculated badge should remain showing IQ score
                debugLog('[Content] Keeping calculated badge with cached guess for tweet:', tweetId);
              } else {
                // No cached guess but badge is already calculated - keep it as calculated
              }
            }
          }
        }
      }
    }
  }

  /**
   * Initialize the extension
   */
  function init() {
    const tweetProcessor = getTweetProcessor();
    const realtimeManager = getRealtimeManager();

    if (!tweetProcessor || !tweetProcessor.processVisibleTweets || !tweetProcessor.setupObserver) {
      console.error('TweetProcessor not available');
      setTimeout(init, 100); // Retry after modules load
      return;
    }

    // Attach click handlers to existing badges
    attachBadgeClickHandlers();

    // Set up observer to attach handlers to newly added badges
    const badgeObserver = new MutationObserver(() => {
      attachBadgeClickHandlers();
    });

    badgeObserver.observe(document.body, {
      childList: true,
      subtree: true
    });

    // Realtime feature is disabled - no need to check for RealtimeManager
    // if (!realtimeManager || !realtimeManager.setupRealtimeComposeObserver) {
    //   console.error('RealtimeManager not available');
    //   setTimeout(init, 100); // Retry after modules load
    //   return;
    // }

    const { processVisibleTweets, setupObserver } = tweetProcessor;
    // const { setupRealtimeComposeObserver } = realtimeManager; // Realtime feature disabled
    const settings = getSettings();

    // Set up settings listener to apply changes immediately
    if (settings && settings.setupSettingsListener) {
      settings.setupSettingsListener((changes) => {
        // Apply settings changes immediately when they change
        if (changes && Object.keys(changes).length > 0) {
          applySettingsChanges(changes);
        }
      });
    }

    // Process existing tweets immediately to show loading badges as fast as possible
    const isNotificationsPage = window.location.href.includes('/notifications');
    
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        // Process immediately - badges should appear as soon as page loads
        processVisibleTweets();
        setupObserver();
        
        // On notification page, also process after a short delay to catch tweets that render late
        if (isNotificationsPage) {
          setTimeout(() => {
            processVisibleTweets();
          }, 500);
          setTimeout(() => {
            processVisibleTweets();
          }, 1500);
        }
        
        // Realtime feature is disabled - do not initialize
        // setupRealtimeComposeObserver();

        // Apply IQGuessr mode if enabled on page load
        applyIQGuessrModeOnLoad();
      });
    } else {
      // Page already loaded - process immediately
      processVisibleTweets();
      setupObserver();
      
      // On notification page, also process after a short delay to catch tweets that render late
      if (isNotificationsPage) {
        setTimeout(() => {
          processVisibleTweets();
        }, 500);
        setTimeout(() => {
          processVisibleTweets();
        }, 1500);
      }
      
      // Realtime feature is disabled - do not initialize
      // setupRealtimeComposeObserver();

      // Apply IQGuessr mode if enabled on page load
      applyIQGuessrModeOnLoad();
    }

    // Performance optimization: Throttled scroll handler with requestIdleCallback
    let scrollTimeout;
    let scrollRafScheduled = false;
    window.addEventListener('scroll', () => {
      clearTimeout(scrollTimeout);
      
      // Use requestAnimationFrame for immediate visual updates, then debounce processing
      if (!scrollRafScheduled) {
        scrollRafScheduled = true;
        requestAnimationFrame(() => {
          scrollRafScheduled = false;
          
          // Use requestIdleCallback for non-critical tweet processing
          const processOnScroll = () => {
            processVisibleTweets();
          };
          
          if (typeof requestIdleCallback !== 'undefined') {
            requestIdleCallback(processOnScroll, { timeout: 200 });
          } else {
            scrollTimeout = setTimeout(processOnScroll, 100);
          }
        });
      }
    }, { passive: true });
  }

  // Handle messages from popup (e.g., clear cache)
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'clearAllCaches') {
      // Clear in-memory caches
      const iqCache = window.IQCache;
      if (iqCache && typeof iqCache.clearCache === 'function') {
        iqCache.clearCache();
      }

      // Clear game manager cache if available
      const gameManager = getGameManager();
      if (gameManager && gameManager.clearCache && typeof gameManager.clearCache === 'function') {
        gameManager.clearCache();
      }

      // Clear any cached IQ results on tweet elements
      const allTweets = document.querySelectorAll('article[data-testid="tweet"], article[role="article"]');
      allTweets.forEach(tweet => {
        delete tweet._iqResult;
        tweet.removeAttribute('data-iq-analyzed');
        tweet.removeAttribute('data-iq-processing');
      });

      sendResponse({ success: true });
      return true; // Keep channel open for async response
    }
  });

  // Wait a moment for all modules to load, then start
  // Modules are loaded synchronously via manifest, but we give a small delay
  // to ensure all window.* global objects are set up
  setTimeout(() => {
    init();
  }, 100);
})();
